import React from 'react';
import { X, Play, Clock, Sparkles } from 'lucide-react';
import { VideoProject } from '../types/video';
import { PRESET_TEMPLATES } from '../data/presetTemplates';

interface TemplateGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: VideoProject) => void;
}

export const TemplateGalleryModal: React.FC<TemplateGalleryModalProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-4xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Studio Video Templates</span>
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Instant 1-click playable video templates crafted with multi-shot camera movement and kinetic motion.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Templates Grid */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4">
          {PRESET_TEMPLATES.map((tmpl) => (
            <div
              key={tmpl.id}
              onClick={() => {
                onSelectTemplate(tmpl);
                onClose();
              }}
              className="group bg-neutral-950 border border-neutral-800 hover:border-indigo-500 rounded-xl overflow-hidden transition-all hover:shadow-xl hover:shadow-indigo-500/10 cursor-pointer flex flex-col justify-between"
            >
              {/* Thumbnail image if available */}
              <div className="relative aspect-video bg-neutral-900 overflow-hidden">
                {tmpl.shots[0]?.imageUrl ? (
                  <img
                    src={tmpl.shots[0].imageUrl}
                    alt={tmpl.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-950 to-neutral-950">
                    <Sparkles className="w-8 h-8 text-indigo-400 opacity-60" />
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                {/* Duration and Aspect ratio badges */}
                <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-[11px] text-white">
                  <span className="font-semibold drop-shadow">{tmpl.title}</span>
                  <div className="flex items-center gap-1.5 font-mono text-[10px] bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded">
                    <Clock className="w-2.5 h-2.5 text-indigo-400" />
                    <span>{tmpl.duration}s</span>
                  </div>
                </div>

                {/* Hover Play Button */}
                <div className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-indigo-600/90 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity transform group-hover:scale-110 shadow-lg">
                  <Play className="w-4 h-4 ml-0.5" />
                </div>
              </div>

              {/* Description & Metadata */}
              <div className="p-3.5 space-y-2">
                <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                  {tmpl.description}
                </p>

                <div className="flex items-center justify-between text-[10px] text-neutral-500 pt-1 border-t border-neutral-800/80">
                  <span className="capitalize">{tmpl.musicGenre} soundtrack</span>
                  <span>{tmpl.shots.length} camera shots</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

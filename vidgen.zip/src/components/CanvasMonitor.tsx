import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Maximize2,
  SkipBack,
  SkipForward,
  Repeat,
  Camera,
} from 'lucide-react';
import { VideoProject } from '../types/video';
import { VideoRenderer, RESOLUTION_MAP, preloadImage } from '../utils/videoRenderer';
import { audioEngine } from '../utils/audioEngine';

interface CanvasMonitorProps {
  project: VideoProject;
  currentTime: number;
  onTimeChange: (time: number) => void;
  selectedShotIndex: number;
  onSelectShot: (index: number) => void;
}

export const CanvasMonitor: React.FC<CanvasMonitorProps> = ({
  project,
  currentTime,
  onTimeChange,
  selectedShotIndex,
  onSelectShot,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<VideoRenderer | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const lastTimeRef = useRef<number>(performance.now());
  const activeShotIndexRef = useRef<number>(selectedShotIndex);

  const totalDuration = project.shots.reduce((acc, s) => acc + s.duration, 0) || 1;

  // Preload project images on mount or project change
  useEffect(() => {
    project.shots.forEach((shot) => {
      if (shot.imageUrl) {
        preloadImage(shot.imageUrl).catch(() => {});
      }
    });
  }, [project]);

  // Initialize Canvas & VideoRenderer
  useEffect(() => {
    if (!canvasRef.current) return;
    const res = RESOLUTION_MAP[project.aspectRatio] || { width: 1920, height: 1080 };
    canvasRef.current.width = res.width;
    canvasRef.current.height = res.height;
    rendererRef.current = new VideoRenderer(canvasRef.current);

    // Initial frame render
    rendererRef.current.renderFrame(project, currentTime);
  }, [project.aspectRatio]);

  // Re-render when time or project changes
  useEffect(() => {
    if (rendererRef.current) {
      rendererRef.current.renderFrame(project, currentTime);
    }
  }, [project, currentTime]);

  // Main Playback Loop
  const tick = useCallback(
    (now: number) => {
      const delta = (now - lastTimeRef.current) / 1000;
      lastTimeRef.current = now;

      let nextTime = currentTime + delta;

      if (nextTime >= totalDuration) {
        if (isLooping) {
          nextTime = 0;
        } else {
          setIsPlaying(false);
          audioEngine.stopMusic();
          audioEngine.stopNarration();
          return;
        }
      }

      onTimeChange(nextTime);

      // Check for shot change to trigger voiceover
      if (rendererRef.current) {
        const { shotIndex, shot } = rendererRef.current.getActiveShotAtTime(project, nextTime);
        if (shotIndex !== activeShotIndexRef.current) {
          activeShotIndexRef.current = shotIndex;
          onSelectShot(shotIndex);
          if (project.enableVoiceover && shot.narration && !isMuted) {
            audioEngine.speakNarration(shot.narration);
          }
        }
      }

      animFrameRef.current = requestAnimationFrame(tick);
    },
    [currentTime, totalDuration, isLooping, project, isMuted, onTimeChange, onSelectShot]
  );

  useEffect(() => {
    if (isPlaying) {
      lastTimeRef.current = performance.now();
      audioEngine.startMusic(project.musicGenre, isMuted ? 0 : project.musicVolume);

      // Trigger initial shot voiceover if starting from beginning
      if (rendererRef.current) {
        const { shot, shotIndex } = rendererRef.current.getActiveShotAtTime(project, currentTime);
        activeShotIndexRef.current = shotIndex;
        if (project.enableVoiceover && shot.narration && !isMuted) {
          audioEngine.speakNarration(shot.narration);
        }
      }

      animFrameRef.current = requestAnimationFrame(tick);
    } else {
      audioEngine.stopMusic();
      audioEngine.stopNarration();
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
    }

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, tick]);

  // Toggle Play / Pause
  const togglePlay = () => {
    setIsPlaying((prev) => !prev);
  };

  // Step Frame
  const stepFrame = (seconds: number) => {
    setIsPlaying(false);
    audioEngine.stopMusic();
    audioEngine.stopNarration();
    const newTime = Math.max(0, Math.min(currentTime + seconds, totalDuration));
    onTimeChange(newTime);
  };

  // Rewind to start
  const handleReset = () => {
    setIsPlaying(false);
    audioEngine.stopMusic();
    audioEngine.stopNarration();
    onTimeChange(0);
  };

  // Toggle Mute
  const toggleMute = () => {
    setIsMuted((prev) => {
      const next = !prev;
      audioEngine.setMusicVolume(next ? 0 : project.musicVolume);
      if (next) audioEngine.stopNarration();
      return next;
    });
  };

  // Fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      containerRef.current.requestFullscreen();
    }
  };

  // Format Timecode: MM:SS.SS
  const formatTimecode = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = (sec % 60).toFixed(1);
    return `${mins.toString().padStart(2, '0')}:${secs.padStart(4, '0')}`;
  };

  // Active shot info
  const activeShot = project.shots[selectedShotIndex] || project.shots[0];

  return (
    <div
      ref={containerRef}
      className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-lg flex flex-col"
    >
      {/* Top Monitor Info Strip */}
      <div className="flex items-center justify-between px-4 py-2 bg-neutral-950/60 border-b border-neutral-800 text-[11px] text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="font-mono-numbers text-xs text-indigo-400 font-semibold">
            {formatTimecode(currentTime)}
          </span>
          <span className="text-neutral-600">/</span>
          <span className="font-mono-numbers text-neutral-400">
            {formatTimecode(totalDuration)}
          </span>
          <span className="text-neutral-700" aria-hidden="true">·</span>
          <span className="truncate max-w-[200px] text-neutral-300">
            {activeShot?.title || 'Scene'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-1.5 py-0.5 rounded bg-neutral-800 text-[10px] font-mono uppercase text-neutral-300 flex items-center gap-1">
            <Camera className="w-2.5 h-2.5 text-indigo-400" />
            {activeShot?.cameraMove.replace('_', ' ')}
          </span>
          <span className="px-1.5 py-0.5 rounded bg-neutral-800 text-[10px] font-mono text-neutral-300">
            {project.aspectRatio}
          </span>
        </div>
      </div>

      {/* Main Canvas Viewport Area */}
      <div className="relative flex-1 bg-black flex items-center justify-center p-3 overflow-hidden min-h-[300px] max-h-[520px]">
        <canvas
          ref={canvasRef}
          className="max-w-full max-h-[480px] object-contain rounded shadow-2xl transition-all"
          style={{
            aspectRatio: project.aspectRatio === '16:9' ? '16/9' : project.aspectRatio === '9:16' ? '9/16' : '1/1',
          }}
        />

        {/* Big Center Play Overlay Button when paused */}
        {!isPlaying && (
          <button
            onClick={togglePlay}
            className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-neutral-900/80 hover:bg-indigo-600 text-white flex items-center justify-center backdrop-blur-sm shadow-xl transition-all hover:scale-105 active:scale-95 cursor-pointer"
            aria-label="Play video"
          >
            <Play className="w-6 h-6 ml-1" />
          </button>
        )}
      </div>

      {/* Scrubbable Timeline Bar */}
      <div className="px-4 pt-2 bg-neutral-950/70 border-t border-neutral-800/80">
        <div className="relative group py-1 cursor-pointer">
          <input
            type="range"
            min={0}
            max={totalDuration}
            step={0.05}
            value={currentTime}
            onChange={(e) => {
              const t = parseFloat(e.target.value);
              onTimeChange(t);
              if (rendererRef.current) {
                const { shotIndex } = rendererRef.current.getActiveShotAtTime(project, t);
                onSelectShot(shotIndex);
              }
            }}
            className="w-full h-1.5 bg-neutral-800 accent-indigo-500 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>

      {/* Playback Controls Footer Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-neutral-950/90 text-neutral-300">
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleReset}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            title="Restart (0:00)"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => stepFrame(-0.1)}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            title="Step Back 0.1s"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={togglePlay}
            className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white transition-colors cursor-pointer shadow-sm shadow-indigo-600/30"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>

          <button
            onClick={() => stepFrame(0.1)}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            title="Step Forward 0.1s"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsLooping((l) => !l)}
            className={`p-1.5 rounded hover:bg-neutral-800 transition-colors cursor-pointer ${
              isLooping ? 'text-indigo-400' : 'text-neutral-500'
            }`}
            title={isLooping ? 'Looping enabled' : 'Looping disabled'}
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
            title="Fullscreen Monitor"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

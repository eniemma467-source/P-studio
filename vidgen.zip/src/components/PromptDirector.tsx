import React, { useState } from 'react';
import {
  Sparkles,
  Wand2,
  Clock,
  Ratio,
  Music2,
  Clapperboard,
  ClipboardPaste,
  Users,
  Check,
} from 'lucide-react';
import { AspectRatio, Character, MusicGenre } from '../types/video';

interface PromptDirectorProps {
  onGenerate: (params: {
    prompt: string;
    aspectRatio: AspectRatio;
    duration: number;
    shotCount: number;
    musicGenre: MusicGenre;
    characters: Character[];
  }) => Promise<void>;
  isGenerating: boolean;
  currentAspectRatio: AspectRatio;
  characters: Character[];
  onOpenCharacterManager: () => void;
}

const INSPIRATION_PROMPTS = [
  'Futuristic neon cyberpunk city with flying transport vehicles and rainy reflections',
  'Cinematic drone shot of turquoise ocean waves crashing on volcanic basalt cliffs',
  'Titanium 3D geometric ribbons undulating with copper edge highlights and studio light',
  'Nostalgic lo-fi anime twilight street with glowing ramen sign and cozy rain',
  'Deep cosmic nebula voyage passing through golden star dust and gravitational rings',
  'Minimalist luxury smartwatch teaser rotating in pitch black void with laser contour',
];

export const PromptDirector: React.FC<PromptDirectorProps> = ({
  onGenerate,
  isGenerating,
  currentAspectRatio,
  characters,
  onOpenCharacterManager,
}) => {
  const [prompt, setPrompt] = useState(
    'Maya navigates the neon spires of Neo-Kyoto as rain pours down on wet holographic streets, while Commander Vance monitors the comm link from orbit.'
  );
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(currentAspectRatio);
  const [duration, setDuration] = useState<number>(12);
  const [shotCount, setShotCount] = useState<number>(3);
  const [musicGenre, setMusicGenre] = useState<MusicGenre>('synthwave');
  const [selectedCharacterIds, setSelectedCharacterIds] = useState<string[]>(
    characters.map((c) => c.id)
  );

  const handleEnhancePrompt = () => {
    const enhancements = [
      'cinematic 8k volumetric lighting, 35mm anamorphic lens, continuous camera dolly, hyper-detailed motion graphics',
      'golden hour natural backlight, shallow depth of field, slow-motion drone flythrough, evocative ambient texture',
      'dark studio minimalism, brushed metallic rim reflections, dynamic orbital perspective, sleek typography',
    ];
    const picked = enhancements[Math.floor(Math.random() * enhancements.length)];
    if (!prompt.includes('cinematic')) {
      setPrompt(`${prompt.trim()}, ${picked}`);
    }
  };

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setPrompt(text);
      }
    } catch (e) {
      // In case clipboard read is blocked by browser permissions, alert friendly tip
      const textarea = document.getElementById('director-prompt-input');
      if (textarea) textarea.focus();
    }
  };

  const toggleCharacterSelection = (id: string) => {
    setSelectedCharacterIds((prev) =>
      prev.includes(id) ? prev.filter((cId) => cId !== id) : [...prev, id]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    const castToSend = characters.filter((c) => selectedCharacterIds.includes(c.id));

    onGenerate({
      prompt: prompt.trim(),
      aspectRatio,
      duration,
      shotCount,
      musicGenre,
      characters: castToSend,
    });
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm space-y-4">
      {/* Header with Title and Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clapperboard className="w-4 h-4 text-indigo-400" />
          <h2 className="text-sm font-semibold text-white">AI Video Director</h2>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handlePasteClipboard}
            className="flex items-center gap-1 text-[11px] text-neutral-300 hover:text-white px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-750 transition-colors cursor-pointer"
            title="Paste prompt or script from clipboard"
          >
            <ClipboardPaste className="w-3.5 h-3.5 text-indigo-400" />
            <span>Paste Script</span>
          </button>

          <button
            type="button"
            onClick={handleEnhancePrompt}
            className="flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Enhance</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Main Prompt / Script Textarea */}
        <div className="relative">
          <textarea
            id="director-prompt-input"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            placeholder="Paste your video prompt, narrative script, dialogue, or describe any scene..."
            className="w-full bg-neutral-950 border border-neutral-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-lg p-3 text-xs text-neutral-100 placeholder-neutral-500 resize-none outline-none transition-colors leading-relaxed"
          />
          <div className="text-[10px] text-neutral-500 text-right mt-1">
            {prompt.split(/\s+/).filter(Boolean).length} words
          </div>
        </div>

        {/* Cast Characters Integration Tray */}
        <div className="space-y-2 bg-neutral-950/70 border border-neutral-800/80 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-medium text-neutral-300 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              <span>Cast Characters in Video ({characters.length})</span>
            </span>
            <button
              type="button"
              onClick={onOpenCharacterManager}
              className="text-[11px] text-indigo-400 hover:text-indigo-300 transition-colors font-medium cursor-pointer"
            >
              + Upload / Manage
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            {characters.map((char) => {
              const isSelected = selectedCharacterIds.includes(char.id);
              return (
                <button
                  key={char.id}
                  type="button"
                  onClick={() => toggleCharacterSelection(char.id)}
                  className={`flex items-center gap-2 pl-1 pr-2.5 py-1 rounded-lg border text-xs transition-all cursor-pointer ${
                    isSelected
                      ? 'border-indigo-500 bg-indigo-950/50 text-white shadow-sm ring-1 ring-indigo-500'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  <img
                    src={char.avatarUrl}
                    alt={char.name}
                    className="w-5 h-5 rounded-md object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-[11px] font-medium">{char.name}</span>
                  {isSelected && <Check className="w-3 h-3 text-indigo-400 ml-0.5" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick Inspiration Prompts */}
        <div className="space-y-1.5">
          <span className="text-[11px] font-medium text-neutral-400">Quick Themes:</span>
          <div className="flex flex-wrap gap-1.5">
            {INSPIRATION_PROMPTS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPrompt(p)}
                className="text-[11px] px-2.5 py-1 rounded bg-neutral-950 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800/80 transition-colors truncate max-w-xs cursor-pointer"
              >
                {p.slice(0, 36)}...
              </button>
            ))}
          </div>
        </div>

        {/* Configuration Row: Aspect Ratio, Duration, Shots, Music */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          {/* Aspect Ratio */}
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
              <Ratio className="w-3 h-3 text-neutral-400" />
              <span>Aspect Ratio</span>
            </label>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
            >
              <option value="16:9">16:9 Landscape</option>
              <option value="9:16">9:16 Reel / TikTok</option>
              <option value="1:1">1:1 Square</option>
              <option value="21:9">21:9 Cinema</option>
              <option value="4:3">4:3 Classic</option>
            </select>
          </div>

          {/* Duration */}
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
              <Clock className="w-3 h-3 text-neutral-400" />
              <span>Duration</span>
            </label>
            <select
              value={duration}
              onChange={(e) => setDuration(Number(e.target.value))}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
            >
              <option value={6}>6 seconds</option>
              <option value={12}>12 seconds</option>
              <option value={18}>18 seconds</option>
              <option value={24}>24 seconds</option>
            </select>
          </div>

          {/* Shot Count */}
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
              <Clapperboard className="w-3 h-3 text-neutral-400" />
              <span>Shot Count</span>
            </label>
            <select
              value={shotCount}
              onChange={(e) => setShotCount(Number(e.target.value))}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
            >
              <option value={2}>2 Scenes</option>
              <option value={3}>3 Scenes</option>
              <option value={4}>4 Scenes</option>
              <option value={5}>5 Scenes</option>
            </select>
          </div>

          {/* Music Soundtrack */}
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
              <Music2 className="w-3 h-3 text-neutral-400" />
              <span>Soundtrack</span>
            </label>
            <select
              value={musicGenre}
              onChange={(e) => setMusicGenre(e.target.value as MusicGenre)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
            >
              <option value="synthwave">Synthwave 80s</option>
              <option value="cinematic">Cinematic Epic</option>
              <option value="lofi">Lo-Fi Chill</option>
              <option value="ambient">Ambient Space</option>
              <option value="techno">Modern Techno</option>
              <option value="corporate">Corporate Uplift</option>
              <option value="dramatic">Dramatic Tension</option>
              <option value="calm">Calm Zen</option>
            </select>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isGenerating || !prompt.trim()}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg shadow-md shadow-indigo-600/20 disabled:opacity-50 transition-all cursor-pointer"
          >
            <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>
              {isGenerating
                ? 'Synthesizing Storyboard & Casting Characters...'
                : 'Generate Video from Prompt (Free)'}
            </span>
          </button>
        </div>
      </form>
    </div>
  );
};

import React, { useRef } from 'react';
import {
  Plus,
  Trash2,
  Copy,
  ChevronLeft,
  ChevronRight,
  Camera,
  Layers,
  Type,
  Music,
} from 'lucide-react';
import { Shot, VideoProject } from '../types/video';

interface TimelineEditorProps {
  project: VideoProject;
  currentTime: number;
  onTimeChange: (time: number) => void;
  selectedShotIndex: number;
  onSelectShot: (index: number) => void;
  onUpdateProject: (updated: VideoProject) => void;
}

export const TimelineEditor: React.FC<TimelineEditorProps> = ({
  project,
  currentTime,
  onTimeChange,
  selectedShotIndex,
  onSelectShot,
  onUpdateProject,
}) => {
  const timelineRef = useRef<HTMLDivElement | null>(null);
  const totalDuration = project.shots.reduce((acc, s) => acc + s.duration, 0) || 1;

  // Handle click on timeline ruler or track to scrub
  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineRef.current) return;
    const rect = timelineRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    onTimeChange(ratio * totalDuration);
  };

  // Add new shot
  const handleAddShot = () => {
    const newShot: Shot = {
      id: `shot-${Date.now()}`,
      title: `Shot ${project.shots.length + 1}: Expansion`,
      duration: 3.5,
      cameraMove: 'dolly_in',
      visualTheme: 'abstract_3d',
      lighting: 'clean_studio',
      primaryText: 'NEW CHAPTER',
      secondaryText: 'Expanding Creative Horizon',
      textAnimation: 'cinematic_fade',
      narration: 'And the vision unfolds into endless new possibilities.',
      transition: 'crossfade',
      primaryColor: '#06b6d4',
      secondaryColor: '#3b82f6',
      accentColor: '#f59e0b',
      backgroundColor: '#030712',
      proceduralElements: ['particles', 'light_rays', 'grid'],
    };

    const updated = {
      ...project,
      shots: [...project.shots, newShot],
      duration: totalDuration + newShot.duration,
    };
    onUpdateProject(updated);
    onSelectShot(project.shots.length);
  };

  // Duplicate selected shot
  const handleDuplicateShot = (index: number) => {
    const shotToDup = project.shots[index];
    if (!shotToDup) return;

    const dupShot: Shot = {
      ...shotToDup,
      id: `shot-${Date.now()}`,
      title: `${shotToDup.title} (Copy)`,
    };

    const newShots = [...project.shots];
    newShots.splice(index + 1, 0, dupShot);

    onUpdateProject({
      ...project,
      shots: newShots,
      duration: totalDuration + dupShot.duration,
    });
    onSelectShot(index + 1);
  };

  // Delete shot
  const handleDeleteShot = (index: number) => {
    if (project.shots.length <= 1) return; // Keep at least 1 shot
    const newShots = project.shots.filter((_, i) => i !== index);
    const newDuration = newShots.reduce((acc, s) => acc + s.duration, 0);

    onUpdateProject({
      ...project,
      shots: newShots,
      duration: newDuration,
    });
    onSelectShot(Math.max(0, index - 1));
  };

  // Move shot left/right
  const handleMoveShot = (index: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= project.shots.length) return;

    const newShots = [...project.shots];
    const temp = newShots[index];
    newShots[index] = newShots[targetIndex];
    newShots[targetIndex] = temp;

    onUpdateProject({
      ...project,
      shots: newShots,
    });
    onSelectShot(targetIndex);
  };

  const playheadPercent = (currentTime / totalDuration) * 100;

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4 shadow-sm space-y-3">
      {/* Timeline Controls & Quick Actions */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span className="font-semibold text-white">Storyboard Timeline</span>
          <span className="text-neutral-500 font-mono text-[11px]">
            {project.shots.length} Scenes · {totalDuration.toFixed(1)}s Total
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => handleMoveShot(selectedShotIndex, 'left')}
            disabled={selectedShotIndex === 0}
            className="p-1 text-neutral-400 hover:text-white disabled:opacity-30 rounded hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Move Shot Left"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleMoveShot(selectedShotIndex, 'right')}
            disabled={selectedShotIndex === project.shots.length - 1}
            className="p-1 text-neutral-400 hover:text-white disabled:opacity-30 rounded hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Move Shot Right"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleDuplicateShot(selectedShotIndex)}
            className="flex items-center gap-1 px-2 py-1 text-[11px] text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors cursor-pointer"
            title="Duplicate Scene"
          >
            <Copy className="w-3 h-3" />
            <span>Duplicate</span>
          </button>
          <button
            onClick={() => handleDeleteShot(selectedShotIndex)}
            disabled={project.shots.length <= 1}
            className="p-1 text-neutral-400 hover:text-red-400 disabled:opacity-30 rounded hover:bg-neutral-800 transition-colors cursor-pointer"
            title="Delete Shot"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleAddShot}
            className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded transition-colors cursor-pointer shadow-sm shadow-indigo-600/30"
          >
            <Plus className="w-3 h-3" />
            <span>Add Scene</span>
          </button>
        </div>
      </div>

      {/* Multi-Track Timeline Canvas Area */}
      <div className="relative select-none overflow-x-auto">
        <div
          ref={timelineRef}
          onClick={handleTimelineClick}
          className="relative min-w-[600px] h-32 bg-neutral-950/80 border border-neutral-800 rounded-lg p-2.5 cursor-pointer overflow-hidden flex flex-col justify-between"
        >
          {/* Track 1: Time Ruler */}
          <div className="h-4 border-b border-neutral-800/80 flex items-center justify-between text-[10px] font-mono text-neutral-500 px-1 pointer-events-none">
            <span>0.0s</span>
            <span>{(totalDuration * 0.25).toFixed(1)}s</span>
            <span>{(totalDuration * 0.5).toFixed(1)}s</span>
            <span>{(totalDuration * 0.75).toFixed(1)}s</span>
            <span>{totalDuration.toFixed(1)}s</span>
          </div>

          {/* Track 2: Shot Blocks */}
          <div className="h-12 flex gap-1.5 pt-1">
            {project.shots.map((shot, idx) => {
              const widthPct = (shot.duration / totalDuration) * 100;
              const isSelected = idx === selectedShotIndex;

              return (
                <div
                  key={shot.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectShot(idx);
                    // Jump playhead to start of shot
                    let accum = 0;
                    for (let s = 0; s < idx; s++) accum += project.shots[s].duration;
                    onTimeChange(accum);
                  }}
                  style={{ width: `${widthPct}%` }}
                  className={`h-full rounded-md p-1.5 flex flex-col justify-between relative transition-all border text-left cursor-pointer ${
                    isSelected
                      ? 'border-indigo-400 bg-indigo-950/50 shadow-md shadow-indigo-500/20 ring-1 ring-indigo-400'
                      : 'border-neutral-800 bg-neutral-900/90 hover:bg-neutral-800/90'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 overflow-hidden">
                    <span className="text-[11px] font-bold text-white truncate">
                      {shot.title}
                    </span>
                    <span className="text-[9px] font-mono text-indigo-300 shrink-0">
                      {shot.duration}s
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-[9px] text-neutral-400">
                    <span className="flex items-center gap-0.5 truncate uppercase">
                      <Camera className="w-2.5 h-2.5 text-neutral-400" />
                      {shot.cameraMove.replace('_', ' ')}
                    </span>
                    <span className="text-neutral-600">·</span>
                    <span className="truncate text-neutral-300">{shot.transition}</span>
                  </div>

                  {/* Color accent line */}
                  <div
                    className="absolute bottom-0 left-0 right-0 h-0.5 rounded-b-md"
                    style={{ backgroundColor: shot.accentColor || '#6366f1' }}
                  />
                </div>
              );
            })}
          </div>

          {/* Track 3: Kinetic Text Strip */}
          <div className="h-5 flex gap-1.5 items-center bg-neutral-900/40 rounded px-1.5 text-[10px] text-neutral-400">
            <Type className="w-3 h-3 text-indigo-400 shrink-0 mr-1" />
            <div className="flex-1 flex gap-1.5 overflow-hidden">
              {project.shots.map((shot) => {
                const widthPct = (shot.duration / totalDuration) * 100;
                return (
                  <div
                    key={`text-${shot.id}`}
                    style={{ width: `${widthPct}%` }}
                    className="truncate text-neutral-300 font-mono text-[9px]"
                  >
                    "{shot.primaryText}"
                  </div>
                );
              })}
            </div>
          </div>

          {/* Track 4: Soundtrack Waveform Strip */}
          <div className="h-5 flex items-center justify-between px-2 bg-neutral-900/60 rounded text-[10px] text-neutral-400">
            <div className="flex items-center gap-1.5">
              <Music className="w-3 h-3 text-cyan-400" />
              <span className="capitalize font-medium text-neutral-300">
                {project.musicGenre} Track
              </span>
            </div>
            {/* Visual audio bars simulation */}
            <div className="flex items-center gap-0.5 h-3">
              {[40, 70, 30, 90, 60, 45, 80, 100, 50, 75, 60, 35, 85, 95, 40].map((h, i) => (
                <div
                  key={i}
                  style={{ height: `${h}%` }}
                  className="w-1 bg-cyan-500/40 rounded-full"
                />
              ))}
            </div>
          </div>

          {/* Vertical Playhead Cursor Line */}
          <div
            style={{ left: `${playheadPercent}%` }}
            className="absolute top-0 bottom-0 w-0.5 bg-indigo-400 shadow-md shadow-indigo-400 pointer-events-none z-10"
          >
            <div className="w-2.5 h-2.5 bg-indigo-400 rounded-full -ml-1 -mt-0.5 shadow-lg ring-2 ring-white" />
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { X, Download, Film, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { ExportProgress, ExportSettings, VideoProject } from '../types/video';
import { videoExporter } from '../utils/videoExporter';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: VideoProject;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose, project }) => {
  const [settings, setSettings] = useState<ExportSettings>({
    resolution: '1080p',
    fps: 30,
    format: 'webm',
  });

  const [progress, setProgress] = useState<ExportProgress>({
    isExporting: false,
    progress: 0,
    currentFrame: 0,
    totalFrames: 0,
    statusText: '',
    videoUrl: null,
    error: null,
  });

  if (!isOpen) return null;

  const handleStartExport = async () => {
    try {
      await videoExporter.exportVideo(project, settings, (p) => {
        setProgress(p);
      });
    } catch (err: any) {
      setProgress((prev) => ({
        ...prev,
        isExporting: false,
        error: err.message || 'Export error occurred',
      }));
    }
  };

  const handleCancel = () => {
    videoExporter.cancel();
    setProgress((prev) => ({
      ...prev,
      isExporting: false,
      statusText: 'Export cancelled',
    }));
  };

  const downloadFilename = `${project.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${settings.resolution}.${settings.format}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-xl overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-bold text-white">Export Video</h2>
          </div>
          <button
            onClick={() => {
              if (progress.isExporting) handleCancel();
              onClose();
            }}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* If video is finished and ready for download */}
          {progress.videoUrl ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Video Rendered Successfully!</span>
              </div>

              {/* Video Preview */}
              <div className="aspect-video bg-black rounded-lg overflow-hidden border border-neutral-800 shadow-inner">
                <video
                  src={progress.videoUrl}
                  controls
                  autoPlay
                  loop
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-neutral-400">
                  Ready for YouTube, TikTok, Reels, or presentation.
                </span>
                <a
                  href={progress.videoUrl}
                  download={downloadFilename}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Video ({settings.resolution})</span>
                </a>
              </div>
            </div>
          ) : progress.isExporting ? (
            /* Live Encoding Progress */
            <div className="space-y-4 py-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-white font-medium flex items-center gap-2">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />
                  <span>{progress.statusText}</span>
                </span>
                <span className="font-mono text-indigo-400 font-semibold">{progress.progress}%</span>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2.5 bg-neutral-950 rounded-full overflow-hidden border border-neutral-800">
                <div
                  style={{ width: `${progress.progress}%` }}
                  className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all duration-150 rounded-full"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
                <span>
                  Frame {progress.currentFrame} / {progress.totalFrames}
                </span>
                <span>Deterministic 60FPS Sync</span>
              </div>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={handleCancel}
                  className="text-xs text-neutral-400 hover:text-red-400 transition-colors"
                >
                  Cancel Export
                </button>
              </div>
            </div>
          ) : (
            /* Export Settings Selector */
            <div className="space-y-4">
              <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-3.5 space-y-1">
                <div className="text-xs font-semibold text-white">{project.title}</div>
                <div className="text-[11px] text-neutral-400">
                  {project.shots.length} Scenes · {project.aspectRatio} Aspect Ratio · {project.duration}s Duration
                </div>
              </div>

              {/* Resolution selection */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-neutral-300">Target Resolution</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSettings({ ...settings, resolution: '1080p' })}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      settings.resolution === '1080p'
                        ? 'border-indigo-500 bg-indigo-950/30 text-white'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-semibold">1080p Full HD</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">Crystal clear for desktop & TV</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSettings({ ...settings, resolution: '720p' })}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      settings.resolution === '720p'
                        ? 'border-indigo-500 bg-indigo-950/30 text-white'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-semibold">720p Fast HD</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">Faster export, lightweight file</div>
                  </button>
                </div>
              </div>

              {/* Framerate Selection */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-neutral-300">Framerate</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSettings({ ...settings, fps: 30 })}
                    className={`py-2 px-3 rounded-lg border text-center transition-all ${
                      settings.fps === 30
                        ? 'border-indigo-500 bg-indigo-950/30 text-white'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-semibold">30 FPS (Standard)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSettings({ ...settings, fps: 60 })}
                    className={`py-2 px-3 rounded-lg border text-center transition-all ${
                      settings.fps === 60
                        ? 'border-indigo-500 bg-indigo-950/30 text-white'
                        : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span className="text-xs font-semibold">60 FPS (Ultra Smooth)</span>
                  </button>
                </div>
              </div>

              {/* Error warning if any */}
              {progress.error && (
                <div className="p-3 rounded-lg bg-red-950/50 border border-red-800/80 text-red-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{progress.error}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleStartExport}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-semibold shadow-md shadow-indigo-600/30 transition-all hover:scale-[1.01]"
                >
                  <Film className="w-3.5 h-3.5" />
                  <span>Start Free Export</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

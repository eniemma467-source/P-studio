import React, { useState } from 'react';
import {
  X,
  Upload,
  UserPlus,
  Trash2,
  Edit2,
  Check,
  Sparkles,
  Camera,
  Layers,
  Volume2,
} from 'lucide-react';
import { Character, CharacterPlacement } from '../types/video';
import {
  addOrUpdateCharacter,
  deleteStoredCharacter,
  getStoredCharacters,
} from '../utils/characterStorage';
import { preloadImage } from '../utils/videoRenderer';

interface CharacterManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  characters: Character[];
  onUpdateCharacters: (characters: Character[]) => void;
  onAssignToActiveShot?: (characterId: string) => void;
  activeShotTitle?: string;
}

export const CharacterManagerModal: React.FC<CharacterManagerModalProps> = ({
  isOpen,
  onClose,
  characters,
  onUpdateCharacters,
  onAssignToActiveShot,
  activeShotTitle,
}) => {
  const [editingChar, setEditingChar] = useState<Character | null>(null);
  const [isCreating, setIsCreating] = useState<boolean>(false);

  // Form State
  const [name, setName] = useState<string>('');
  const [role, setRole] = useState<string>('');
  const [avatarUrl, setAvatarUrl] = useState<string>('');
  const [badgeColor, setBadgeColor] = useState<string>('#06b6d4');
  const [placement, setPlacement] = useState<CharacterPlacement>('bottom_right_badge');
  const [bio, setBio] = useState<string>('');

  if (!isOpen) return null;

  const handleStartCreate = () => {
    setIsCreating(true);
    setEditingChar(null);
    setName('');
    setRole('');
    setAvatarUrl('');
    setBadgeColor('#06b6d4');
    setPlacement('bottom_right_badge');
    setBio('');
  };

  const handleStartEdit = (char: Character) => {
    setIsCreating(false);
    setEditingChar(char);
    setName(char.name);
    setRole(char.role);
    setAvatarUrl(char.avatarUrl);
    setBadgeColor(char.badgeColor || '#06b6d4');
    setPlacement(char.placement || 'bottom_right_badge');
    setBio(char.bio || '');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setAvatarUrl(result);
        preloadImage(result).catch(() => {});
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !avatarUrl) return;

    const characterToSave: Character = {
      id: editingChar ? editingChar.id : `char-${Date.now()}`,
      name: name.trim(),
      role: role.trim() || 'Cast Member',
      avatarUrl,
      badgeColor,
      placement,
      bio: bio.trim(),
    };

    preloadImage(avatarUrl).catch(() => {});

    const updated = addOrUpdateCharacter(characterToSave);
    onUpdateCharacters(updated);

    // Reset Form
    setIsCreating(false);
    setEditingChar(null);
  };

  const handleDelete = (id: string) => {
    const updated = deleteStoredCharacter(id);
    onUpdateCharacters(updated);
    if (editingChar?.id === id) {
      setEditingChar(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Characters & Cast Studio</span>
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Upload and maintain custom characters. Cast them into video scenes with automated motion, voice, and name tags.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Layout */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-12 gap-6 flex-1">
          {/* Left Column: Character List (7 cols) */}
          <div className="md:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-neutral-300">
                Maintained Characters ({characters.length})
              </span>
              <button
                type="button"
                onClick={handleStartCreate}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm shadow-indigo-600/30 transition-colors cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Upload New Character</span>
              </button>
            </div>

            {/* Character Cards List */}
            <div className="space-y-3">
              {characters.map((char) => (
                <div
                  key={char.id}
                  className={`bg-neutral-950 border rounded-xl p-3.5 flex items-center justify-between gap-4 transition-all ${
                    editingChar?.id === char.id
                      ? 'border-indigo-500 ring-1 ring-indigo-500 bg-neutral-900'
                      : 'border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    {/* Character Avatar */}
                    <div
                      className="w-14 h-14 rounded-xl overflow-hidden border-2 shrink-0 bg-neutral-900 shadow"
                      style={{ borderColor: char.badgeColor || '#6366f1' }}
                    >
                      <img
                        src={char.avatarUrl}
                        alt={char.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white truncate">
                          {char.name}
                        </span>
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: char.badgeColor || '#06b6d4' }}
                          title="Badge Color"
                        />
                      </div>
                      <div className="text-[11px] text-neutral-400 truncate">
                        {char.role}
                      </div>
                      <div className="text-[10px] text-neutral-500 capitalize flex items-center gap-1.5 mt-0.5">
                        <Camera className="w-2.5 h-2.5 text-neutral-400" />
                        <span>{char.placement?.replace(/_/g, ' ') || 'Bottom badge'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {onAssignToActiveShot && (
                      <button
                        type="button"
                        onClick={() => {
                          onAssignToActiveShot(char.id);
                          onClose();
                        }}
                        className="px-2.5 py-1 text-[11px] font-medium text-indigo-300 hover:text-white bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-800/80 rounded transition-colors cursor-pointer"
                        title={activeShotTitle ? `Assign to "${activeShotTitle}"` : 'Cast in scene'}
                      >
                        Cast in Scene
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleStartEdit(char)}
                      className="p-1.5 text-neutral-400 hover:text-white hover:bg-neutral-800 rounded transition-colors cursor-pointer"
                      title="Edit Character"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(char.id)}
                      className="p-1.5 text-neutral-400 hover:text-red-400 hover:bg-neutral-800 rounded transition-colors cursor-pointer"
                      title="Delete Character"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Character Form (5 cols) */}
          <div className="md:col-span-5 bg-neutral-950 border border-neutral-800 rounded-xl p-4.5 space-y-4">
            <div className="border-b border-neutral-800 pb-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-white">
                {isCreating
                  ? 'Add Character'
                  : editingChar
                  ? `Edit "${editingChar.name}"`
                  : 'Character Details'}
              </span>
              {(isCreating || editingChar) && (
                <button
                  type="button"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingChar(null);
                  }}
                  className="text-[11px] text-neutral-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
              )}
            </div>

            {isCreating || editingChar ? (
              <form onSubmit={handleSave} className="space-y-3.5">
                {/* Avatar Portrait Upload */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-medium text-neutral-400">
                    Character Portrait Image
                  </label>
                  <div className="flex items-center gap-3">
                    <div
                      className="w-16 h-16 rounded-xl overflow-hidden border-2 bg-neutral-900 shrink-0 flex items-center justify-center shadow"
                      style={{ borderColor: badgeColor }}
                    >
                      {avatarUrl ? (
                        <img
                          src={avatarUrl}
                          alt="Preview"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <Upload className="w-6 h-6 text-neutral-600" />
                      )}
                    </div>

                    <label className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-dashed border-neutral-800 hover:border-indigo-500 bg-neutral-900 hover:bg-neutral-850 text-neutral-300 hover:text-white text-xs transition-colors cursor-pointer">
                      <Upload className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Upload Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {/* Character Name */}
                <div className="space-y-1">
                  <label className="text-[11px] font-medium text-neutral-400">Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Maya, Captain Vance, Dr. Lee"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs text-white focus:border-indigo-500 outline-none"
                  />
                </div>

                {/* Role / Tagline */}
                <div className="space-y-1">
                  <label className="text-[11px] font-medium text-neutral-400">
                    Role / Tagline
                  </label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="e.g. Lead Pilot, Keynote Host, Co-founder"
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs text-white focus:border-indigo-500 outline-none"
                  />
                </div>

                {/* Placement & Color */}
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-neutral-400">
                      Screen Framing
                    </label>
                    <select
                      value={placement}
                      onChange={(e) => setPlacement(e.target.value as CharacterPlacement)}
                      className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
                    >
                      <option value="bottom_right_badge">Bottom Badge</option>
                      <option value="portrait_left">Portrait Left</option>
                      <option value="portrait_right">Portrait Right</option>
                      <option value="center_focus">Center Focus</option>
                      <option value="hologram">Hologram</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-medium text-neutral-400">
                      Badge Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={badgeColor}
                        onChange={(e) => setBadgeColor(e.target.value)}
                        className="w-7 h-7 rounded border border-neutral-800 bg-transparent cursor-pointer p-0"
                      />
                      <span className="font-mono text-xs text-neutral-400">{badgeColor}</span>
                    </div>
                  </div>
                </div>

                {/* Bio / Persona Notes */}
                <div className="space-y-1">
                  <label className="text-[11px] font-medium text-neutral-400">
                    Personality & Prompt Notes
                  </label>
                  <textarea
                    rows={2}
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Describe their backstory so the AI director matches their persona..."
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-lg p-2 text-xs text-neutral-200 focus:border-indigo-500 outline-none resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={!name.trim() || !avatarUrl}
                  className="w-full py-2 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {isCreating ? 'Save New Character' : 'Update Character'}
                </button>
              </form>
            ) : (
              <div className="text-center py-10 space-y-3 text-neutral-500">
                <div className="w-12 h-12 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mx-auto text-neutral-400">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div className="text-xs text-neutral-400">
                  Select a character to edit, or click <strong>Upload New Character</strong> to add your own avatar.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

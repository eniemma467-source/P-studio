import React from 'react';
import { Film, Download, Sparkles, FolderOpen, Users } from 'lucide-react';

interface TopBarProps {
  onOpenTemplates: () => void;
  onOpenCharacters: () => void;
  onOpenExport: () => void;
  onNewProject: () => void;
  isGenerating: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  onOpenTemplates,
  onOpenCharacters,
  onOpenExport,
  onNewProject,
  isGenerating,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-neutral-800 bg-neutral-900/90 backdrop-blur-md sticky top-0 z-30">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
          <Film className="w-4 h-4" />
        </div>
        <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
          CineCraft <span className="font-normal text-xs text-indigo-400 tracking-normal ml-1">Studio</span>
        </span>
      </div>

      {/* Zone 2: Clean unboxed navigation / view tabs */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-neutral-400">
        <button
          onClick={onOpenTemplates}
          className="flex items-center gap-1.5 hover:text-white transition-colors whitespace-nowrap shrink-0 text-left cursor-pointer"
        >
          <FolderOpen className="w-3.5 h-3.5 text-neutral-400" />
          <span>Templates</span>
        </button>
        <span className="text-neutral-700" aria-hidden="true">·</span>
        <button
          onClick={onOpenCharacters}
          className="flex items-center gap-1.5 hover:text-white transition-colors whitespace-nowrap shrink-0 text-left cursor-pointer"
        >
          <Users className="w-3.5 h-3.5 text-indigo-400" />
          <span>Cast & Characters</span>
        </button>
        <span className="text-neutral-700" aria-hidden="true">·</span>
        <button
          onClick={onNewProject}
          className="flex items-center gap-1.5 hover:text-white transition-colors whitespace-nowrap shrink-0 text-left cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Paste / New Prompt</span>
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onOpenTemplates}
          className="md:hidden px-3 py-1.5 text-xs font-medium text-neutral-300 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          Templates
        </button>
        <button
          onClick={onOpenExport}
          disabled={isGenerating}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-lg shadow-sm shadow-indigo-500/25 transition-colors disabled:opacity-50 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export HD Video</span>
        </button>
      </div>
    </header>
  );
};

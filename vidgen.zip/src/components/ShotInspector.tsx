import React from 'react';
import {
  Camera,
  Palette,
  Type,
  Volume2,
  Sparkles,
  Image as ImageIcon,
  Sliders,
  Maximize2,
  Trash2,
  Upload,
  User,
  Users,
} from 'lucide-react';
import {
  CameraMove,
  Character,
  CharacterPlacement,
  Shot,
  TextAnimation,
  TransitionType,
  VisualTheme,
} from '../types/video';
import { audioEngine } from '../utils/audioEngine';

interface ShotInspectorProps {
  shot: Shot;
  shotIndex: number;
  totalShots: number;
  characters: Character[];
  onOpenCharacterManager: () => void;
  onUpdateShot: (updated: Shot) => void;
}

const STOCK_BACKDROPS = [
  {
    name: 'Cyberpunk Metropolis',
    url: '/src/assets/images/cyberpunk_cityscape_1794148767201.jpg',
  },
  {
    name: 'Pacific Volcanic Tide',
    url: '/src/assets/images/nature_aerial_coast_1794148767649.jpg',
  },
  {
    name: 'Titanium Waves',
    url: '/src/assets/images/abstract_kinetic_flow_1794148768820.jpg',
  },
  {
    name: 'Lo-Fi Anime Twilight',
    url: '/src/assets/images/retro_sunset_lofi_1794148768119.jpg',
  },
];

export const ShotInspector: React.FC<ShotInspectorProps> = ({
  shot,
  shotIndex,
  totalShots,
  characters,
  onOpenCharacterManager,
  onUpdateShot,
}) => {
  const handleChange = <K extends keyof Shot>(field: K, value: Shot[K]) => {
    onUpdateShot({
      ...shot,
      [field]: value,
    });
  };

  const handleTestVoice = () => {
    if (shot.narration) {
      audioEngine.speakNarration(shot.narration);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        handleChange('imageUrl', dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const assignedCharacter = characters.find((c) => c.id === shot.characterId);

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-semibold text-white">
            Scene Inspector <span className="text-xs text-neutral-400 font-normal">#{shotIndex + 1} of {totalShots}</span>
          </h3>
        </div>

        {/* Duration slider in header */}
        <div className="flex items-center gap-2">
          <label className="text-[11px] text-neutral-400 font-mono">
            {shot.duration.toFixed(1)}s
          </label>
          <input
            type="range"
            min={1.5}
            max={8.0}
            step={0.5}
            value={shot.duration}
            onChange={(e) => handleChange('duration', parseFloat(e.target.value))}
            className="w-20 h-1.5 bg-neutral-800 accent-indigo-500 rounded cursor-pointer"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left Column: Camera & Theme & Backdrop */}
        <div className="space-y-3.5">
          {/* Scene Title */}
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-400">Scene Title</label>
            <input
              type="text"
              value={shot.title}
              onChange={(e) => handleChange('title', e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs text-white focus:border-indigo-500 outline-none"
            />
          </div>

          {/* Cast Member in Scene */}
          <div className="space-y-1.5 bg-neutral-950/80 border border-neutral-800/80 rounded-lg p-2.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-medium text-neutral-300 flex items-center gap-1.5">
                <Users className="w-3 h-3 text-indigo-400" />
                <span>Featured Character</span>
              </label>
              <button
                type="button"
                onClick={onOpenCharacterManager}
                className="text-[10px] text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
              >
                + Manage Cast
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <select
                value={shot.characterId || ''}
                onChange={(e) => handleChange('characterId', e.target.value || undefined)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-200 outline-none focus:border-indigo-500"
              >
                <option value="">None (Scenery only)</option>
                {characters.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.role})
                  </option>
                ))}
              </select>

              <select
                disabled={!shot.characterId}
                value={shot.characterPlacement || assignedCharacter?.placement || 'bottom_right_badge'}
                onChange={(e) => handleChange('characterPlacement', e.target.value as CharacterPlacement)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-200 outline-none focus:border-indigo-500 disabled:opacity-40"
              >
                <option value="bottom_right_badge">Bottom Badge</option>
                <option value="portrait_left">Portrait Left</option>
                <option value="portrait_right">Portrait Right</option>
                <option value="center_focus">Center Focus</option>
                <option value="hologram">Hologram</option>
              </select>
            </div>
          </div>

          {/* Camera Motion & Visual Theme */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
                <Camera className="w-3 h-3 text-neutral-400" />
                <span>Camera Motion</span>
              </label>
              <select
                value={shot.cameraMove}
                onChange={(e) => handleChange('cameraMove', e.target.value as CameraMove)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
              >
                <option value="dolly_in">Dolly In (Zoom In)</option>
                <option value="dolly_out">Dolly Out (Pull Back)</option>
                <option value="pan_left">Pan Left</option>
                <option value="pan_right">Pan Right</option>
                <option value="tilt_up">Tilt Up</option>
                <option value="orbital">Orbital 3D Arc</option>
                <option value="zoom_crash">Zoom Crash Punch</option>
                <option value="static">Static Locked Frame</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
                <Palette className="w-3 h-3 text-neutral-400" />
                <span>Visual Shader</span>
              </label>
              <select
                value={shot.visualTheme}
                onChange={(e) => handleChange('visualTheme', e.target.value as VisualTheme)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
              >
                <option value="cyberpunk">Cyberpunk Neon</option>
                <option value="synthwave_grid">Synthwave Grid</option>
                <option value="nature">Volcanic Nature</option>
                <option value="abstract_3d">3D Organic Waves</option>
                <option value="cinematic_space">Cosmic Starfield</option>
                <option value="matrix_code">Matrix Digital Rain</option>
                <option value="aurora_borealis">Aurora Borealis</option>
                <option value="lofi_twilight">Lo-Fi Twilight</option>
                <option value="particles_gold">Golden Embers</option>
              </select>
            </div>
          </div>

          {/* Keyframe Backdrop Selector */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
                <ImageIcon className="w-3 h-3 text-neutral-400" />
                <span>Keyframe Backdrop</span>
              </label>
              {shot.imageUrl && (
                <button
                  type="button"
                  onClick={() => handleChange('imageUrl', undefined)}
                  className="text-[10px] text-neutral-500 hover:text-red-400 transition-colors"
                >
                  Clear (Use Procedural)
                </button>
              )}
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {STOCK_BACKDROPS.map((bd, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleChange('imageUrl', bd.url)}
                  className={`relative aspect-video rounded-md overflow-hidden border transition-all ${
                    shot.imageUrl === bd.url
                      ? 'border-indigo-500 ring-2 ring-indigo-500/50'
                      : 'border-neutral-800 hover:border-neutral-700 opacity-70 hover:opacity-100'
                  }`}
                  title={bd.name}
                >
                  <img
                    src={bd.url}
                    alt={bd.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </button>
              ))}
            </div>

            {/* Custom Image Upload */}
            <div className="pt-1">
              <label className="flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg border border-dashed border-neutral-800 hover:border-neutral-700 bg-neutral-950/60 hover:bg-neutral-950 text-neutral-400 hover:text-white text-xs transition-colors cursor-pointer">
                <Upload className="w-3 h-3" />
                <span>Upload Custom Keyframe Image</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Right Column: Kinetic Typography & Voiceover & Colors */}
        <div className="space-y-3.5">
          {/* Primary Text Overlay */}
          <div className="space-y-1">
            <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
              <Type className="w-3 h-3 text-neutral-400" />
              <span>Hero Headline (Kinetic Text)</span>
            </label>
            <input
              type="text"
              value={shot.primaryText}
              onChange={(e) => handleChange('primaryText', e.target.value)}
              placeholder="e.g. UNLIMITED CREATION"
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs text-white uppercase focus:border-indigo-500 outline-none"
            />
          </div>

          {/* Subtitle & Animation Style */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-400">Subtitle</label>
              <input
                type="text"
                value={shot.secondaryText}
                onChange={(e) => handleChange('secondaryText', e.target.value)}
                placeholder="e.g. Next Gen Motion Engine"
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-white focus:border-indigo-500 outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-400">Text Animation</label>
              <select
                value={shot.textAnimation}
                onChange={(e) => handleChange('textAnimation', e.target.value as TextAnimation)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
              >
                <option value="glitch_reveal">Glitch Chromatic Reveal</option>
                <option value="cinematic_fade">Cinematic Letter Spacing</option>
                <option value="slide_up">Smooth Vertical Slide</option>
                <option value="scale_pop">Impact Scale Pop</option>
                <option value="typewriter">Typewriter Scanline</option>
              </select>
            </div>
          </div>

          {/* Voiceover Script & Listen Button */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-medium text-neutral-400 flex items-center gap-1">
                <Volume2 className="w-3 h-3 text-neutral-400" />
                <span>Voiceover Script Line</span>
              </label>
              <button
                type="button"
                onClick={handleTestVoice}
                className="flex items-center gap-1 text-[10px] text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                <Volume2 className="w-2.5 h-2.5" />
                <span>Preview Voice</span>
              </button>
            </div>
            <textarea
              rows={2}
              value={shot.narration}
              onChange={(e) => handleChange('narration', e.target.value)}
              placeholder="What the narrator speaks during this shot..."
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg p-2 text-xs text-neutral-200 focus:border-indigo-500 outline-none resize-none"
            />
          </div>

          {/* Transition & Color Accents */}
          <div className="grid grid-cols-2 gap-2.5 items-end">
            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-400">Exit Transition</label>
              <select
                value={shot.transition}
                onChange={(e) => handleChange('transition', e.target.value as TransitionType)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-200 outline-none focus:border-indigo-500"
              >
                <option value="crossfade">Crossfade Dissolve</option>
                <option value="whip_pan">Whip Pan Blur</option>
                <option value="glitch">Glitch Slice Flash</option>
                <option value="zoom_fade">Hyper-Zoom Fade</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-medium text-neutral-400">Accent Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={shot.accentColor}
                  onChange={(e) => handleChange('accentColor', e.target.value)}
                  className="w-7 h-7 rounded border border-neutral-800 bg-transparent cursor-pointer p-0"
                />
                <span className="font-mono text-xs text-neutral-400">{shot.accentColor}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

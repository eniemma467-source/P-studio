export type AspectRatio = '16:9' | '9:16' | '1:1' | '21:9' | '4:3';

export type CameraMove =
  | 'dolly_in'
  | 'dolly_out'
  | 'pan_left'
  | 'pan_right'
  | 'tilt_up'
  | 'orbital'
  | 'zoom_crash'
  | 'static';

export type VisualTheme =
  | 'cyberpunk'
  | 'nature'
  | 'abstract_3d'
  | 'lofi_twilight'
  | 'cinematic_space'
  | 'matrix_code'
  | 'minimalist_luxury'
  | 'synthwave_grid'
  | 'aurora_borealis'
  | 'particles_gold';

export type TextAnimation =
  | 'glitch_reveal'
  | 'typewriter'
  | 'cinematic_fade'
  | 'slide_up'
  | 'scale_pop'
  | 'split_words';

export type TransitionType =
  | 'crossfade'
  | 'whip_pan'
  | 'glitch'
  | 'zoom_fade'
  | 'slide';

export type MusicGenre =
  | 'synthwave'
  | 'cinematic'
  | 'lofi'
  | 'ambient'
  | 'techno'
  | 'corporate'
  | 'dramatic'
  | 'calm';

export type CharacterPlacement =
  | 'bottom_right_badge'
  | 'portrait_left'
  | 'portrait_right'
  | 'center_focus'
  | 'hologram';

export interface Character {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  badgeColor?: string;
  voiceName?: string;
  bio?: string;
  placement?: CharacterPlacement;
}

export interface Shot {
  id: string;
  title: string;
  duration: number; // in seconds, e.g. 3.5
  cameraMove: CameraMove;
  visualTheme: VisualTheme;
  lighting: string;
  primaryText: string;
  secondaryText: string;
  textAnimation: TextAnimation;
  narration: string;
  transition: TransitionType;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  proceduralElements: string[];
  imageUrl?: string; // Optional image backdrop or keyframe
  characterId?: string; // Optional assigned character
  characterPlacement?: CharacterPlacement;
}

export interface VideoProject {
  id: string;
  title: string;
  description: string;
  aspectRatio: AspectRatio;
  duration: number; // Total duration in seconds
  musicGenre: MusicGenre;
  musicVolume: number; // 0 to 1
  voiceVolume: number; // 0 to 1
  enableVoiceover: boolean;
  shots: Shot[];
  characters?: Character[];
}

export interface ExportSettings {
  resolution: '720p' | '1080p';
  fps: 30 | 60;
  format: 'webm' | 'mp4';
}

export interface ExportProgress {
  isExporting: boolean;
  progress: number; // 0 to 100
  currentFrame: number;
  totalFrames: number;
  statusText: string;
  videoUrl: string | null;
  error: string | null;
}

import { AspectRatio, Shot, VideoProject } from '../types/video';

// Canvas resolution presets
export const RESOLUTION_MAP: Record<AspectRatio, { width: number; height: number }> = {
  '16:9': { width: 1920, height: 1080 },
  '9:16': { width: 1080, height: 1920 },
  '1:1': { width: 1080, height: 1080 },
  '21:9': { width: 2560, height: 1080 },
  '4:3': { width: 1440, height: 1080 },
};

// Image element cache to avoid re-decoding every frame
const imageCache: Map<string, HTMLImageElement> = new Map();

export function preloadImage(url: string): Promise<HTMLImageElement> {
  if (imageCache.has(url)) {
    return Promise.resolve(imageCache.get(url)!);
  }
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = url;
    img.onload = () => {
      imageCache.set(url, img);
      resolve(img);
    };
    img.onerror = () => {
      reject(new Error(`Failed to load image: ${url}`));
    };
  });
}

export class VideoRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private particles: Array<{ x: number; y: number; size: number; speed: number; alpha: number; angle: number }> = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false, willReadFrequently: false });
    if (!ctx) throw new Error('Could not get 2D canvas context');
    this.ctx = ctx;

    // Initialize 120 particle motes
    for (let i = 0; i < 120; i++) {
      this.particles.push({
        x: Math.random(),
        y: Math.random(),
        size: Math.random() * 3 + 1,
        speed: Math.random() * 0.05 + 0.01,
        alpha: Math.random() * 0.7 + 0.2,
        angle: Math.random() * Math.PI * 2,
      });
    }
  }

  // Determine active shot and shot-local progress for a given global time (seconds)
  public getActiveShotAtTime(project: VideoProject, timeSec: number): {
    shot: Shot;
    shotIndex: number;
    shotStartTime: number;
    shotProgress: number; // 0 to 1
    transitionProgress: number; // 0 to 1 if in transition zone
    nextShot?: Shot;
  } {
    const totalDuration = project.shots.reduce((acc, s) => acc + s.duration, 0) || 1;
    const clampedTime = Math.max(0, Math.min(timeSec, totalDuration));

    let accumulated = 0;
    for (let i = 0; i < project.shots.length; i++) {
      const shot = project.shots[i];
      const start = accumulated;
      const end = accumulated + shot.duration;

      if (clampedTime >= start && (clampedTime < end || i === project.shots.length - 1)) {
        const localTime = clampedTime - start;
        const shotProgress = Math.min(1, Math.max(0, localTime / shot.duration));

        // Transition zone in the last 0.6 seconds of the shot
        const transitionDuration = 0.6;
        let transitionProgress = 0;
        let nextShot: Shot | undefined = undefined;

        if (i < project.shots.length - 1 && localTime > shot.duration - transitionDuration) {
          transitionProgress = (localTime - (shot.duration - transitionDuration)) / transitionDuration;
          nextShot = project.shots[i + 1];
        }

        return {
          shot,
          shotIndex: i,
          shotStartTime: start,
          shotProgress,
          transitionProgress,
          nextShot,
        };
      }
      accumulated = end;
    }

    return {
      shot: project.shots[0],
      shotIndex: 0,
      shotStartTime: 0,
      shotProgress: 0,
      transitionProgress: 0,
    };
  }

  // Main Render Frame method
  public renderFrame(project: VideoProject, timeSec: number) {
    const { width, height } = this.canvas;
    const ctx = this.ctx;

    const { shot, shotProgress, transitionProgress, nextShot } = this.getActiveShotAtTime(
      project,
      timeSec
    );

    // Save initial context state
    ctx.save();
    ctx.fillStyle = shot.backgroundColor || '#05070f';
    ctx.fillRect(0, 0, width, height);

    // 1. Draw Background Image or Procedural Theme
    this.renderShotVisual(shot, shotProgress, width, height, timeSec);

    // 2. Draw Procedural Overlays (Atmosphere, particles, light rays)
    this.renderAtmosphericOverlays(shot, shotProgress, width, height, timeSec);

    // 3. Draw Cast Character Layer if assigned
    this.renderCharacterLayer(project, shot, shotProgress, width, height, timeSec);

    // 4. Draw Kinetic Typography & Text Overlays
    this.renderKineticTypography(shot, shotProgress, width, height);

    // 5. Handle Shot Transition (Crossfade / Whip Pan / Glitch)
    if (transitionProgress > 0 && nextShot) {
      this.renderTransition(shot, nextShot, transitionProgress, width, height, timeSec);
    }

    // 6. Cinematic Vignette and Film Letterbox / Edge Finish
    this.renderCinematicFraming(width, height);

    ctx.restore();
  }

  // Render the primary visual background for a shot
  private renderShotVisual(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;

    // Check if image backdrop exists
    if (shot.imageUrl && imageCache.has(shot.imageUrl)) {
      const img = imageCache.get(shot.imageUrl)!;
      this.renderKenBurnsImage(img, shot.cameraMove, progress, width, height);
      return;
    }

    // Otherwise render dynamic procedural scene based on visualTheme
    switch (shot.visualTheme) {
      case 'cyberpunk':
      case 'synthwave_grid':
        this.renderSynthwaveGrid(shot, progress, width, height, timeSec);
        break;
      case 'cinematic_space':
      case 'particles_gold':
        this.renderStarfieldAndNebula(shot, progress, width, height, timeSec);
        break;
      case 'abstract_3d':
        this.renderOrganicFluidWaves(shot, progress, width, height, timeSec);
        break;
      case 'matrix_code':
        this.renderMatrixGlyphs(shot, progress, width, height, timeSec);
        break;
      case 'aurora_borealis':
        this.renderAurora(shot, progress, width, height, timeSec);
        break;
      case 'lofi_twilight':
      default:
        this.renderAtmosphericGradient(shot, progress, width, height, timeSec);
        break;
    }
  }

  // Camera Motion applied to Image Backdrops (Ken Burns effect)
  private renderKenBurnsImage(
    img: HTMLImageElement,
    cameraMove: string,
    progress: number,
    width: number,
    height: number
  ) {
    const ctx = this.ctx;
    ctx.save();

    let scale = 1.0;
    let translateX = 0;
    let translateY = 0;

    switch (cameraMove) {
      case 'dolly_in':
        scale = 1.0 + progress * 0.18; // smooth 18% zoom in
        break;
      case 'dolly_out':
        scale = 1.18 - progress * 0.18;
        break;
      case 'pan_left':
        scale = 1.12;
        translateX = (0.5 - progress) * width * 0.08;
        break;
      case 'pan_right':
        scale = 1.12;
        translateX = (progress - 0.5) * width * 0.08;
        break;
      case 'tilt_up':
        scale = 1.1;
        translateY = (progress - 0.5) * height * 0.07;
        break;
      case 'orbital':
        scale = 1.08 + Math.sin(progress * Math.PI) * 0.05;
        translateX = Math.sin(progress * Math.PI * 2) * width * 0.02;
        translateY = Math.cos(progress * Math.PI * 2) * height * 0.015;
        break;
      case 'zoom_crash':
        scale = 1.0 + Math.pow(progress, 2.5) * 0.35;
        break;
      default:
        scale = 1.04;
    }

    ctx.translate(width / 2, height / 2);
    ctx.scale(scale, scale);
    ctx.translate(-width / 2 + translateX, -height / 2 + translateY);

    // Cover calculation preserving aspect ratio
    const imgRatio = img.width / img.height;
    const canvasRatio = width / height;
    let drawW = width;
    let drawH = height;
    let offsetX = 0;
    let offsetY = 0;

    if (canvasRatio > imgRatio) {
      drawW = width;
      drawH = width / imgRatio;
      offsetY = (height - drawH) / 2;
    } else {
      drawH = height;
      drawW = height * imgRatio;
      offsetX = (width - drawW) / 2;
    }

    ctx.drawImage(img, offsetX, offsetY, drawW, drawH);

    // Subtle dark contrast scrim
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, 'rgba(0,0,0,0.4)');
    grad.addColorStop(0.5, 'rgba(0,0,0,0.2)');
    grad.addColorStop(1, 'rgba(0,0,0,0.65)');
    ctx.fillStyle = grad;
    ctx.fillRect(offsetX, offsetY, drawW, drawH);

    ctx.restore();
  }

  // Procedural: 3D Perspective Synthwave Wireframe Grid
  private renderSynthwaveGrid(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    const horizon = height * 0.55;

    // Sky gradient
    const skyGrad = ctx.createLinearGradient(0, 0, 0, horizon);
    skyGrad.addColorStop(0, shot.backgroundColor);
    skyGrad.addColorStop(0.7, shot.secondaryColor);
    skyGrad.addColorStop(1, shot.primaryColor);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, width, horizon);

    // Sun disc at horizon
    ctx.save();
    const sunRadius = Math.min(width, height) * 0.16;
    const sunX = width / 2;
    const sunY = horizon - sunRadius * 0.2;
    const sunGrad = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, sunRadius);
    sunGrad.addColorStop(0, '#fef08a');
    sunGrad.addColorStop(0.6, shot.accentColor);
    sunGrad.addColorStop(1, 'rgba(236, 72, 153, 0)');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(sunX, sunY, sunRadius, 0, Math.PI * 2);
    ctx.fill();

    // Horizontal sun laser cuts
    ctx.fillStyle = shot.backgroundColor;
    for (let y = sunY; y < sunY + sunRadius; y += 12) {
      const sliceH = (y - sunY) / 10;
      ctx.fillRect(sunX - sunRadius, y, sunRadius * 2, sliceH);
    }
    ctx.restore();

    // Ground plane
    ctx.fillStyle = shot.backgroundColor;
    ctx.fillRect(0, horizon, width, height - horizon);

    // Perspective Grid Lines
    ctx.save();
    ctx.strokeStyle = shot.primaryColor;
    ctx.lineWidth = 1.5;
    ctx.shadowColor = shot.primaryColor;
    ctx.shadowBlur = 8;

    // Moving horizontal grid lines (hyperbolic speed perspective)
    const speedOffset = (timeSec * 0.8) % 1;
    for (let i = 0; i < 18; i++) {
      const t = Math.pow((i + speedOffset) / 18, 2.2);
      const y = horizon + t * (height - horizon);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Radial perspective lines converging at center horizon
    const lineCount = 28;
    for (let i = 0; i <= lineCount; i++) {
      const bottomX = (width / lineCount) * i;
      ctx.beginPath();
      ctx.moveTo(sunX, horizon);
      ctx.lineTo(bottomX, height);
      ctx.stroke();
    }
    ctx.restore();
  }

  // Procedural: Cosmic Nebula and Warp Starfield
  private renderStarfieldAndNebula(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    const cx = width / 2;
    const cy = height / 2;

    // Deep cosmic background
    const bgGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, width * 0.8);
    bgGrad.addColorStop(0, shot.secondaryColor + '44');
    bgGrad.addColorStop(0.5, shot.backgroundColor);
    bgGrad.addColorStop(1, '#020208');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, width, height);

    // Glowing nebula clouds
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (let i = 0; i < 4; i++) {
      const angle = (timeSec * 0.1 + (i * Math.PI) / 2);
      const nx = cx + Math.cos(angle) * (width * 0.2);
      const ny = cy + Math.sin(angle) * (height * 0.15);
      const cloudGrad = ctx.createRadialGradient(nx, ny, 10, nx, ny, width * 0.35);
      cloudGrad.addColorStop(0, i % 2 === 0 ? shot.primaryColor + '33' : shot.accentColor + '22');
      cloudGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = cloudGrad;
      ctx.beginPath();
      ctx.arc(nx, ny, width * 0.35, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // Warp-speed star streaks
    ctx.save();
    ctx.fillStyle = '#ffffff';
    for (const p of this.particles) {
      const dist = ((p.speed * timeSec * 4 + p.alpha) % 1);
      const r = dist * (Math.max(width, height) * 0.7);
      const px = cx + Math.cos(p.angle) * r;
      const py = cy + Math.sin(p.angle) * r;
      const trailLen = dist * 25 + 2;

      ctx.strokeStyle = `rgba(255, 255, 255, ${dist * 0.9})`;
      ctx.lineWidth = p.size * (0.5 + dist);
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(px - Math.cos(p.angle) * trailLen, py - Math.sin(p.angle) * trailLen);
      ctx.stroke();
    }
    ctx.restore();
  }

  // Procedural: 3D Organic Fluid Ribbon Waves
  private renderOrganicFluidWaves(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    ctx.fillStyle = shot.backgroundColor;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    const waveCount = 5;
    for (let w = 0; w < waveCount; w++) {
      ctx.beginPath();
      const baseY = height * (0.35 + (w / waveCount) * 0.4);
      ctx.moveTo(0, height);
      ctx.lineTo(0, baseY);

      for (let x = 0; x <= width; x += 30) {
        const wave1 = Math.sin(x * 0.003 + timeSec * 0.8 + w * 1.5) * 80;
        const wave2 = Math.cos(x * 0.006 - timeSec * 0.5 + w) * 40;
        ctx.lineTo(x, baseY + wave1 + wave2);
      }

      ctx.lineTo(width, height);
      ctx.closePath();

      const waveGrad = ctx.createLinearGradient(0, baseY - 60, width, baseY + 120);
      waveGrad.addColorStop(0, shot.primaryColor + (w === 0 ? '99' : '55'));
      waveGrad.addColorStop(0.5, shot.secondaryColor + '66');
      waveGrad.addColorStop(1, shot.backgroundColor);
      ctx.fillStyle = waveGrad;
      ctx.fill();

      // Top edge highlight line
      ctx.strokeStyle = shot.accentColor;
      ctx.lineWidth = 2;
      ctx.shadowColor = shot.accentColor;
      ctx.shadowBlur = 10;
      ctx.stroke();
    }
    ctx.restore();
  }

  // Procedural: Digital Matrix Glyph Rain
  private renderMatrixGlyphs(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    ctx.fillStyle = shot.backgroundColor;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.font = '16px "JetBrains Mono", monospace';
    ctx.fillStyle = shot.primaryColor;

    const cols = Math.floor(width / 32);
    for (let c = 0; c < cols; c++) {
      const x = c * 32;
      const speed = 150 + ((c * 17) % 100);
      const headY = ((timeSec * speed + c * 83) % (height + 200)) - 100;

      // Draw trail of 10 characters
      for (let i = 0; i < 12; i++) {
        const y = headY - i * 22;
        if (y < 0 || y > height) continue;

        const charCode = 65 + ((c + i * 3 + Math.floor(timeSec * 5)) % 26);
        const char = String.fromCharCode(charCode);

        if (i === 0) {
          ctx.fillStyle = '#ffffff';
          ctx.shadowColor = '#ffffff';
          ctx.shadowBlur = 12;
        } else {
          const alpha = 1 - i / 12;
          ctx.fillStyle = shot.primaryColor + Math.floor(alpha * 255).toString(16).padStart(2, '0');
          ctx.shadowBlur = 0;
        }
        ctx.fillText(char, x, y);
      }
    }
    ctx.restore();
  }

  // Procedural: Aurora Borealis Curtains
  private renderAurora(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    ctx.fillStyle = shot.backgroundColor;
    ctx.fillRect(0, 0, width, height);

    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (let a = 0; a < 3; a++) {
      const grad = ctx.createLinearGradient(0, height * 0.1, 0, height * 0.7);
      grad.addColorStop(0, 'transparent');
      grad.addColorStop(0.4, shot.primaryColor + '55');
      grad.addColorStop(0.7, shot.secondaryColor + '44');
      grad.addColorStop(1, 'transparent');

      ctx.beginPath();
      ctx.moveTo(0, height * 0.5);
      for (let x = 0; x <= width; x += 40) {
        const y =
          height * 0.35 +
          Math.sin(x * 0.002 + timeSec * 0.4 + a) * 80 +
          Math.cos(x * 0.005 - timeSec * 0.3) * 40;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height * 0.7);
      ctx.lineTo(0, height * 0.7);
      ctx.fillStyle = grad;
      ctx.fill();
    }
    ctx.restore();
  }

  // Atmospheric Gradient Default
  private renderAtmosphericGradient(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, shot.backgroundColor);
    grad.addColorStop(0.5, shot.secondaryColor + '55');
    grad.addColorStop(1, shot.primaryColor + '33');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
  }

  // Procedural Overlays: Floating Particles & Volumetric Light Rays
  private renderAtmosphericOverlays(
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;

    // 1. Volumetric God Rays
    if (shot.proceduralElements.includes('light_rays')) {
      ctx.save();
      ctx.globalCompositeOperation = 'screen';
      const rayCount = 6;
      for (let r = 0; r < rayCount; r++) {
        const angle = -0.4 + (r / rayCount) * 0.8 + Math.sin(timeSec * 0.3 + r) * 0.05;
        const rayGrad = ctx.createLinearGradient(width * 0.2, 0, width * 0.8, height);
        rayGrad.addColorStop(0, shot.accentColor + '25');
        rayGrad.addColorStop(0.6, shot.primaryColor + '10');
        rayGrad.addColorStop(1, 'transparent');

        ctx.fillStyle = rayGrad;
        ctx.beginPath();
        ctx.moveTo(width * 0.3, 0);
        ctx.lineTo(width * 0.3 + Math.tan(angle) * height, height);
        ctx.lineTo(width * 0.35 + Math.tan(angle) * height + 100, height);
        ctx.lineTo(width * 0.35, 0);
        ctx.fill();
      }
      ctx.restore();
    }

    // 2. Floating Ambient Dust / Embers
    if (shot.proceduralElements.includes('particles')) {
      ctx.save();
      for (const p of this.particles) {
        p.y -= p.speed * 0.003;
        if (p.y < 0) p.y = 1;

        const px = p.x * width + Math.sin(timeSec * 0.5 + p.y * 10) * 15;
        const py = p.y * height;

        ctx.fillStyle = shot.accentColor + Math.floor(p.alpha * 200).toString(16).padStart(2, '0');
        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  // Render Cast Character overlay
  private renderCharacterLayer(
    project: VideoProject,
    shot: Shot,
    progress: number,
    width: number,
    height: number,
    timeSec: number
  ) {
    if (!shot.characterId || !project.characters) return;
    const character = project.characters.find((c) => c.id === shot.characterId);
    if (!character || !character.avatarUrl || !imageCache.has(character.avatarUrl)) return;

    const img = imageCache.get(character.avatarUrl)!;
    const ctx = this.ctx;
    const placement = shot.characterPlacement || character.placement || 'bottom_right_badge';
    const badgeColor = character.badgeColor || shot.accentColor || '#6366f1';

    ctx.save();

    // Smooth entry transition (fade in + position slide over first 15% of shot)
    const enterProgress = Math.min(1, progress / 0.15);
    const exitProgress = progress > 0.88 ? (progress - 0.88) / 0.12 : 0;
    const layerAlpha = enterProgress * (1 - exitProgress);

    if (layerAlpha <= 0) {
      ctx.restore();
      return;
    }

    ctx.globalAlpha = layerAlpha;

    if (placement === 'bottom_right_badge') {
      const badgeSize = Math.round(Math.min(width, height) * 0.16);
      const padding = Math.round(badgeSize * 0.25);
      const x = width - badgeSize - padding;
      const y = height - badgeSize - padding;

      // Outer speaking glow ring
      const pulse = Math.sin(timeSec * 8) * 3;
      ctx.strokeStyle = badgeColor;
      ctx.lineWidth = 3;
      ctx.shadowColor = badgeColor;
      ctx.shadowBlur = 10 + pulse;
      ctx.beginPath();
      ctx.arc(x + badgeSize / 2, y + badgeSize / 2, badgeSize / 2 + 3, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Draw avatar clipped into circle
      ctx.save();
      ctx.beginPath();
      ctx.arc(x + badgeSize / 2, y + badgeSize / 2, badgeSize / 2, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(img, x, y, badgeSize, badgeSize);
      ctx.restore();

      // Name & role badge tag below avatar
      const tagText = character.name.toUpperCase();
      const roleText = character.role || 'Narrator';
      ctx.font = `700 ${Math.round(badgeSize * 0.17)}px 'Plus Jakarta Sans', sans-serif`;
      const textMetrics = ctx.measureText(tagText);
      const tagWidth = Math.max(textMetrics.width + 24, 110);
      const tagHeight = Math.round(badgeSize * 0.38);
      const tagX = x + badgeSize / 2 - tagWidth / 2;
      const tagY = y + badgeSize - tagHeight * 0.25;

      // Badge pill background
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 1;
      this.drawRoundedRect(ctx, tagX, tagY, tagWidth, tagHeight, 8);
      ctx.fill();
      ctx.stroke();

      // Text
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(tagText, tagX + tagWidth / 2, tagY + tagHeight * 0.36);

      ctx.font = `500 ${Math.round(badgeSize * 0.11)}px 'Plus Jakarta Sans', sans-serif`;
      ctx.fillStyle = badgeColor;
      ctx.fillText(roleText, tagX + tagWidth / 2, tagY + tagHeight * 0.74);
    } else if (placement === 'portrait_left' || placement === 'portrait_right') {
      const isLeft = placement === 'portrait_left';
      const pWidth = Math.round(width * 0.28);
      const pHeight = Math.round(height * 0.62);

      const slideOffset = (1 - enterProgress) * (isLeft ? -60 : 60);
      const floatY = Math.sin(timeSec * 1.5) * 5;

      const x = isLeft ? Math.round(width * 0.07) + slideOffset : Math.round(width * 0.65) + slideOffset;
      const y = Math.round(height * 0.34) + floatY;

      // Draw portrait with rounded corners and bottom gradient fade
      ctx.save();
      this.drawRoundedRect(ctx, x, y, pWidth, pHeight, 20);
      ctx.clip();
      ctx.drawImage(img, x, y, pWidth, pHeight);

      // Bottom fade scrim to blend character into scene
      const fadeGrad = ctx.createLinearGradient(x, y + pHeight * 0.5, x, y + pHeight);
      fadeGrad.addColorStop(0, 'rgba(0, 0, 0, 0)');
      fadeGrad.addColorStop(1, 'rgba(0, 0, 0, 0.88)');
      ctx.fillStyle = fadeGrad;
      ctx.fillRect(x, y + pHeight * 0.5, pWidth, pHeight * 0.5);
      ctx.restore();

      // Border frame around portrait
      ctx.strokeStyle = badgeColor + '88';
      ctx.lineWidth = 2;
      this.drawRoundedRect(ctx, x, y, pWidth, pHeight, 20);
      ctx.stroke();

      // Name label tag
      const labelY = y + pHeight - 38;
      ctx.fillStyle = 'rgba(10, 15, 30, 0.88)';
      this.drawRoundedRect(ctx, x + 12, labelY, pWidth - 24, 30, 6);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = `700 13px 'Plus Jakarta Sans', sans-serif`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(character.name.toUpperCase(), x + 22, labelY + 15);

      ctx.fillStyle = badgeColor;
      ctx.font = `500 11px 'Plus Jakarta Sans', sans-serif`;
      ctx.textAlign = 'right';
      ctx.fillText(character.role || 'Cast', x + pWidth - 22, labelY + 15);
    } else if (placement === 'center_focus') {
      const pSize = Math.round(Math.min(width, height) * 0.42);
      const x = (width - pSize) / 2;
      const y = height * 0.28 + Math.sin(timeSec * 1.2) * 4;

      // Glowing circular backdrop
      const rimGrad = ctx.createRadialGradient(
        width / 2,
        y + pSize / 2,
        pSize * 0.4,
        width / 2,
        y + pSize / 2,
        pSize * 0.58
      );
      rimGrad.addColorStop(0, badgeColor + '55');
      rimGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = rimGrad;
      ctx.beginPath();
      ctx.arc(width / 2, y + pSize / 2, pSize * 0.58, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.beginPath();
      ctx.arc(width / 2, y + pSize / 2, pSize / 2, 0, Math.PI * 2);
      ctx.clip();
      ctx.drawImage(img, x, y, pSize, pSize);
      ctx.restore();

      ctx.strokeStyle = badgeColor;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(width / 2, y + pSize / 2, pSize / 2, 0, Math.PI * 2);
      ctx.stroke();
    } else if (placement === 'hologram') {
      // Futuristic holographic projection
      const pSize = Math.round(Math.min(width, height) * 0.32);
      const x = width * 0.68;
      const y = height * 0.22 + Math.sin(timeSec * 2) * 4;

      ctx.save();
      ctx.globalCompositeOperation = 'screen';

      // Cyan / Blue hologram tint
      this.drawRoundedRect(ctx, x, y, pSize, pSize, 14);
      ctx.clip();
      ctx.drawImage(img, x, y, pSize, pSize);

      ctx.fillStyle = 'rgba(6, 182, 212, 0.35)';
      ctx.fillRect(x, y, pSize, pSize);

      // Hologram scanlines
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      for (let s = y; s < y + pSize; s += 6) {
        ctx.fillRect(x, s, pSize, 2);
      }
      ctx.restore();

      // Hologram header
      ctx.font = `600 11px 'JetBrains Mono', monospace`;
      ctx.fillStyle = '#22d3ee';
      ctx.textAlign = 'left';
      ctx.fillText(`COMM LINK // ${character.name.toUpperCase()}`, x, y - 10);
    }

    ctx.restore();
  }

  // Helper to draw rounded rectangle
  private drawRoundedRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  // Kinetic Typography & Subtitles
  private renderKineticTypography(
    shot: Shot,
    progress: number,
    width: number,
    height: number
  ) {
    const ctx = this.ctx;
    ctx.save();

    const cx = width / 2;
    const cy = height * 0.52;

    // Headline timing and animation calculation
    // Appears smoothly over first 20% of shot duration
    const textEnterProgress = Math.min(1, progress / 0.22);
    // Exit animation in the last 15%
    const textExitProgress = progress > 0.85 ? (progress - 0.85) / 0.15 : 0;
    const overallAlpha = textEnterProgress * (1 - textExitProgress);

    if (overallAlpha <= 0) {
      ctx.restore();
      return;
    }

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Scale and font size calculation based on canvas dimension
    const baseFontSize = Math.round(Math.min(width, height) * 0.065);
    ctx.font = `800 ${baseFontSize}px 'Plus Jakarta Sans', system-ui, sans-serif`;

    let offsetY = 0;
    let letterSpacing = 2;
    let headlineScale = 1.0;

    switch (shot.textAnimation) {
      case 'slide_up':
        offsetY = (1 - textEnterProgress) * 45;
        break;
      case 'scale_pop':
        headlineScale = 0.8 + textEnterProgress * 0.2;
        break;
      case 'cinematic_fade':
        letterSpacing = 2 + textEnterProgress * 6;
        break;
      case 'glitch_reveal':
        if (Math.random() > 0.88 && textEnterProgress < 0.8) {
          offsetY = (Math.random() - 0.5) * 8;
        }
        break;
      default:
        offsetY = 0;
    }

    ctx.translate(cx, cy + offsetY);
    ctx.scale(headlineScale, headlineScale);

    // Primary Headline Text
    if (shot.primaryText) {
      const headline = shot.primaryText.toUpperCase();

      // Glitch Chromatic Aberration Effect if glitch animation
      if (shot.textAnimation === 'glitch_reveal' && Math.random() > 0.85) {
        ctx.fillStyle = '#06b6d4';
        ctx.fillText(headline, -4, 0);
        ctx.fillStyle = '#f43f5e';
        ctx.fillText(headline, 4, 0);
      }

      // Strong drop shadow for contrast against any video background
      ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
      ctx.shadowBlur = 18;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 4;

      ctx.fillStyle = `rgba(255, 255, 255, ${overallAlpha})`;
      ctx.fillText(headline, 0, 0);

      // Subtle top highlight sheen
      ctx.shadowBlur = 0;
    }

    // Secondary Subtitle / Punchline
    if (shot.secondaryText) {
      const subFontSize = Math.round(baseFontSize * 0.38);
      ctx.font = `500 ${subFontSize}px 'Plus Jakarta Sans', system-ui, sans-serif`;
      ctx.fillStyle = `${shot.accentColor}${Math.floor(overallAlpha * 230).toString(16).padStart(2, '0')}`;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
      ctx.shadowBlur = 10;
      ctx.shadowOffsetY = 2;

      const subY = baseFontSize * 0.75;
      ctx.fillText(shot.secondaryText, 0, subY);

      // Accent underline indicator
      const textMetrics = ctx.measureText(shot.secondaryText);
      const lineWidth = Math.min(textMetrics.width * 0.7, 180) * textEnterProgress;
      ctx.strokeStyle = shot.accentColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-lineWidth / 2, subY + subFontSize * 0.8);
      ctx.lineTo(lineWidth / 2, subY + subFontSize * 0.8);
      ctx.stroke();
    }

    ctx.restore();
  }

  // Cinematic Transitions between shots
  private renderTransition(
    currentShot: Shot,
    nextShot: Shot,
    progress: number, // 0 to 1
    width: number,
    height: number,
    timeSec: number
  ) {
    const ctx = this.ctx;
    const type = currentShot.transition;

    ctx.save();
    switch (type) {
      case 'whip_pan': {
        // High speed horizontal blur wipe
        const offset = progress * width;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(0, 0, offset, height);

        // Motion blur speed lines
        ctx.strokeStyle = nextShot.primaryColor;
        ctx.lineWidth = 3;
        for (let i = 0; i < 12; i++) {
          const y = (height / 12) * i + Math.random() * 20;
          ctx.beginPath();
          ctx.moveTo(offset - 200, y);
          ctx.lineTo(offset + 100, y);
          ctx.stroke();
        }
        break;
      }
      case 'glitch': {
        // Digital slice and flash
        const sliceCount = 8;
        for (let i = 0; i < sliceCount; i++) {
          const sy = (height / sliceCount) * i;
          const sh = height / sliceCount;
          const dx = (Math.random() - 0.5) * progress * 80;
          ctx.fillStyle = i % 2 === 0 ? nextShot.primaryColor + '44' : nextShot.accentColor + '44';
          ctx.fillRect(dx, sy, width, sh);
        }
        break;
      }
      case 'zoom_fade': {
        // Radial flash zoom
        const flashAlpha = Math.sin(progress * Math.PI) * 0.6;
        ctx.fillStyle = `rgba(255, 255, 255, ${flashAlpha})`;
        ctx.fillRect(0, 0, width, height);
        break;
      }
      case 'crossfade':
      default: {
        // Luminance dissolve
        ctx.fillStyle = `${nextShot.backgroundColor}${Math.floor(progress * 255).toString(16).padStart(2, '0')}`;
        ctx.fillRect(0, 0, width, height);
        break;
      }
    }
    ctx.restore();
  }

  // Cinematic Edge Vignette
  private renderCinematicFraming(width: number, height: number) {
    const ctx = this.ctx;
    const vignette = ctx.createRadialGradient(
      width / 2,
      height / 2,
      Math.min(width, height) * 0.45,
      width / 2,
      height / 2,
      Math.max(width, height) * 0.75
    );
    vignette.addColorStop(0, 'rgba(0, 0, 0, 0)');
    vignette.addColorStop(1, 'rgba(0, 0, 0, 0.55)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, width, height);
  }
}

import { ExportProgress, ExportSettings, VideoProject } from '../types/video';
import { audioEngine } from './audioEngine';
import { preloadImage, RESOLUTION_MAP, VideoRenderer } from './videoRenderer';

export class VideoExporter {
  private isCancelled = false;

  public cancel() {
    this.isCancelled = true;
  }

  public async exportVideo(
    project: VideoProject,
    settings: ExportSettings,
    onProgress: (progress: ExportProgress) => void
  ): Promise<string> {
    this.isCancelled = false;

    // 1. Preload any images in the project
    onProgress({
      isExporting: true,
      progress: 2,
      currentFrame: 0,
      totalFrames: 100,
      statusText: 'Preloading textures and keyframe assets...',
      videoUrl: null,
      error: null,
    });

    const imageUrls = project.shots.map((s) => s.imageUrl).filter(Boolean) as string[];
    const charUrls = (project.characters?.map((c) => c.avatarUrl) || []).filter(Boolean) as string[];
    const allUrls = Array.from(new Set([...imageUrls, ...charUrls]));

    await Promise.all(
      allUrls.map((url) =>
        preloadImage(url).catch((err) => {
          console.warn('Asset preload failed, falling back to procedural:', err);
        })
      )
    );

    // 2. Setup offscreen export canvas with selected resolution
    const res = RESOLUTION_MAP[project.aspectRatio] || { width: 1920, height: 1080 };
    const exportWidth = settings.resolution === '720p' ? Math.round(res.width * 0.666) : res.width;
    const exportHeight = settings.resolution === '720p' ? Math.round(res.height * 0.666) : res.height;

    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = exportWidth;
    exportCanvas.height = exportHeight;

    const renderer = new VideoRenderer(exportCanvas);

    // 3. Setup MediaStream and Recorder
    const fps = settings.fps;
    const totalDuration = project.shots.reduce((acc, s) => acc + s.duration, 0);
    const totalFrames = Math.max(1, Math.round(totalDuration * fps));

    const canvasStream = exportCanvas.captureStream(fps);

    // Attach audio track if audio stream is available
    const audioStream = audioEngine.getAudioStream();
    if (audioStream && audioStream.getAudioTracks().length > 0) {
      audioStream.getAudioTracks().forEach((track) => {
        canvasStream.addTrack(track);
      });
    }

    // Determine supported mime type
    let mimeType = 'video/webm;codecs=vp9';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm;codecs=vp8';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm';
      }
    }

    const recordedChunks: Blob[] = [];
    const mediaRecorder = new MediaRecorder(canvasStream, {
      mimeType,
      videoBitsPerSecond: settings.resolution === '1080p' ? 8000000 : 4500000,
    });

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        recordedChunks.push(event.data);
      }
    };

    return new Promise<string>((resolve, reject) => {
      mediaRecorder.onstop = () => {
        if (this.isCancelled) {
          reject(new Error('Export was cancelled by user'));
          return;
        }
        const blob = new Blob(recordedChunks, { type: mimeType });
        const videoUrl = URL.createObjectURL(blob);
        onProgress({
          isExporting: false,
          progress: 100,
          currentFrame: totalFrames,
          totalFrames,
          statusText: 'Video export completed successfully!',
          videoUrl,
          error: null,
        });
        resolve(videoUrl);
      };

      mediaRecorder.onerror = (err: any) => {
        reject(new Error(`MediaRecorder error: ${err.message || 'unknown'}`));
      };

      // Start recording
      mediaRecorder.start();

      // Start soundtrack during export
      audioEngine.startMusic(project.musicGenre, project.musicVolume);

      // Render frame by frame
      let currentFrame = 0;
      const frameDuration = 1 / fps;

      const renderStep = () => {
        if (this.isCancelled) {
          audioEngine.stopMusic();
          try {
            mediaRecorder.stop();
          } catch (e) {}
          return;
        }

        if (currentFrame >= totalFrames) {
          audioEngine.stopMusic();
          setTimeout(() => {
            try {
              mediaRecorder.stop();
            } catch (e) {
              reject(e);
            }
          }, 300);
          return;
        }

        const currentTime = currentFrame * frameDuration;
        renderer.renderFrame(project, currentTime);

        currentFrame++;
        const pct = Math.min(99, Math.round((currentFrame / totalFrames) * 98) + 2);

        onProgress({
          isExporting: true,
          progress: pct,
          currentFrame,
          totalFrames,
          statusText: `Encoding frame ${currentFrame} of ${totalFrames} (${currentTime.toFixed(1)}s / ${totalDuration.toFixed(1)}s)...`,
          videoUrl: null,
          error: null,
        });

        // Use requestAnimationFrame or setTimeout for real-time capture
        requestAnimationFrame(renderStep);
      };

      // Trigger first frame
      renderStep();
    });
  }
}

export const videoExporter = new VideoExporter();

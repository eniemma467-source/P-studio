import { Character } from '../types/video';
import { DEFAULT_CHARACTERS } from '../data/defaultCharacters';

const STORAGE_KEY = 'cinecraft_characters_v1';

export function getStoredCharacters(): Character[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_CHARACTERS));
      return DEFAULT_CHARACTERS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_CHARACTERS;
  } catch (e) {
    console.warn('Failed to load characters from localStorage:', e);
    return DEFAULT_CHARACTERS;
  }
}

export function saveStoredCharacters(characters: Character[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(characters));
  } catch (e) {
    console.warn('Failed to save characters to localStorage:', e);
  }
}

export function addOrUpdateCharacter(char: Character): Character[] {
  const current = getStoredCharacters();
  const index = current.findIndex((c) => c.id === char.id);
  let updated: Character[];

  if (index >= 0) {
    updated = [...current];
    updated[index] = char;
  } else {
    updated = [char, ...current];
  }

  saveStoredCharacters(updated);
  return updated;
}

export function deleteStoredCharacter(id: string): Character[] {
  const current = getStoredCharacters();
  const updated = current.filter((c) => c.id !== id);
  saveStoredCharacters(updated);
  return updated;
}

import { MusicGenre } from '../types/video';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private currentGenre: MusicGenre = 'synthwave';
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private voiceGain: GainNode | null = null;
  private synthInterval: number | null = null;
  private isDucked = false;
  private destinationNode: MediaStreamAudioDestinationNode | null = null;
  private currentSpeechUtterance: SpeechSynthesisUtterance | null = null;

  public init() {
    if (this.ctx) return;
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;

    this.ctx = new AudioCtx();
    this.masterGain = this.ctx.createGain();
    this.musicGain = this.ctx.createGain();
    this.voiceGain = this.ctx.createGain();

    this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
    this.musicGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
    this.voiceGain.gain.setValueAtTime(0.9, this.ctx.currentTime);

    this.musicGain.connect(this.masterGain);
    this.voiceGain.connect(this.masterGain);
    this.masterGain.connect(this.ctx.destination);

    // Create stream destination for MediaRecorder export
    try {
      this.destinationNode = this.ctx.createMediaStreamDestination();
      this.masterGain.connect(this.destinationNode);
    } catch (e) {
      console.warn('Could not create MediaStreamDestination', e);
    }
  }

  public getAudioStream(): MediaStream | null {
    if (!this.destinationNode) return null;
    return this.destinationNode.stream;
  }

  public startMusic(genre: MusicGenre, volume = 0.7) {
    this.init();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    this.stopMusic();
    this.currentGenre = genre;
    this.isPlaying = true;
    this.setMusicVolume(volume);

    let step = 0;
    const tempoMap: Record<MusicGenre, number> = {
      synthwave: 250, // 120 bpm eighth notes
      techno: 230,
      cinematic: 500,
      lofi: 375, // 80 bpm
      ambient: 800,
      corporate: 300,
      dramatic: 350,
      calm: 900,
    };

    const intervalMs = tempoMap[genre] || 300;

    this.synthInterval = window.setInterval(() => {
      if (!this.isPlaying || !this.ctx) return;
      this.playGenreStep(genre, step);
      step = (step + 1) % 16;
    }, intervalMs);
  }

  public stopMusic() {
    this.isPlaying = false;
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }

  public setMusicVolume(vol: number) {
    if (!this.ctx || !this.musicGain) return;
    const clamped = Math.max(0, Math.min(1, vol));
    this.musicGain.gain.setTargetAtTime(
      this.isDucked ? clamped * 0.35 : clamped,
      this.ctx.currentTime,
      0.05
    );
  }

  public setDuck(duck: boolean) {
    this.isDucked = duck;
    if (!this.ctx || !this.musicGain) return;
    const target = duck ? 0.25 : 0.7;
    this.musicGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.1);
  }

  // Play synthesized note with custom envelope
  private playTone(
    freq: number,
    duration: number,
    type: OscillatorType = 'sine',
    gainAmount = 0.15,
    detune = 0
  ) {
    if (!this.ctx || !this.musicGain) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      if (detune) osc.detune.setValueAtTime(detune, this.ctx.currentTime);

      gain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      gain.gain.linearRampToValueAtTime(gainAmount, this.ctx.currentTime + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.musicGain);

      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      // Audio node failure fallback
    }
  }

  private playGenreStep(genre: MusicGenre, step: number) {
    if (!this.ctx) return;

    if (genre === 'synthwave') {
      // 80s rolling bassline in A minor (A, C, D, E)
      const bassNotes = [110, 110, 130.81, 110, 146.83, 110, 164.81, 110];
      const note = bassNotes[step % bassNotes.length];
      this.playTone(note, 0.22, 'sawtooth', 0.12);
      this.playTone(note * 0.5, 0.22, 'triangle', 0.18); // Sub bass

      // Synth chord pad every 4 steps
      if (step % 4 === 0) {
        const chordRoots = [220, 261.63, 293.66, 329.63];
        const root = chordRoots[Math.floor(step / 4) % chordRoots.length];
        this.playTone(root, 1.2, 'sawtooth', 0.06, 5);
        this.playTone(root * 1.189, 1.2, 'sawtooth', 0.05, -5); // Minor third
        this.playTone(root * 1.498, 1.2, 'sawtooth', 0.05, 3); // Fifth
      }

      // Snare / clap noise on steps 4 and 12
      if (step === 4 || step === 12) {
        this.playTone(280, 0.1, 'triangle', 0.15);
      }
    } else if (genre === 'cinematic') {
      // Slow deep brass and strings
      if (step % 4 === 0) {
        const root = 65.41; // C2 deep drone
        this.playTone(root, 2.5, 'sawtooth', 0.15);
        this.playTone(root * 1.5, 2.5, 'sine', 0.12); // Cello Fifth
        this.playTone(root * 2, 2.5, 'triangle', 0.1);
      }
      if (step % 8 === 0) {
        this.playTone(45, 0.6, 'sine', 0.35); // Timpani thunder sub
      }
    } else if (genre === 'lofi') {
      // Warm Rhodes electric piano chords (Maj7/Min7)
      if (step % 4 === 0) {
        const chords = [
          [261.63, 329.63, 392.0, 493.88], // Cmaj7
          [220.0, 261.63, 329.63, 392.0], // Am7
          [174.61, 220.0, 261.63, 329.63], // Fmaj7
          [196.0, 246.94, 293.66, 349.23], // G7
        ];
        const chord = chords[Math.floor(step / 4) % chords.length];
        chord.forEach((freq) => {
          this.playTone(freq, 1.4, 'sine', 0.08);
          this.playTone(freq * 0.998, 1.4, 'triangle', 0.06);
        });
      }
      // Soft kick on step 0 and 10
      if (step === 0 || step === 10) {
        this.playTone(60, 0.2, 'sine', 0.25);
      }
      // Soft rim click on 4 and 12
      if (step === 4 || step === 12) {
        this.playTone(800, 0.04, 'triangle', 0.08);
      }
    } else if (genre === 'ambient') {
      if (step % 4 === 0) {
        const notes = [130.81, 164.81, 196.0, 246.94, 293.66];
        const freq = notes[step % notes.length];
        this.playTone(freq, 3.5, 'sine', 0.09);
        this.playTone(freq * 2.01, 3.0, 'sine', 0.04);
      }
    } else if (genre === 'techno') {
      // 4/4 Kick on every 4 steps
      if (step % 4 === 0) {
        this.playTone(55, 0.15, 'sine', 0.35);
      }
      // Driving 16th arpeggios
      const arp = [110, 130.81, 164.81, 220, 164.81, 130.81, 110, 98];
      const freq = arp[step % arp.length];
      this.playTone(freq * 2, 0.12, 'sawtooth', 0.08);
    } else if (genre === 'calm') {
      // Singing bowl harmonic resonance
      if (step % 8 === 0) {
        const bowlFreq = 174.61; // F3
        this.playTone(bowlFreq, 4.0, 'sine', 0.15);
        this.playTone(bowlFreq * 2.76, 3.0, 'sine', 0.06); // Non-harmonic overtone
        this.playTone(bowlFreq * 5.4, 2.0, 'sine', 0.03);
      }
    } else {
      // Default melodious chord
      if (step % 4 === 0) {
        this.playTone(220, 1.5, 'triangle', 0.1);
        this.playTone(329.63, 1.5, 'sine', 0.08);
      }
    }
  }

  // Voiceover Narration via Web Speech API
  public speakNarration(text: string, onEnd?: () => void) {
    if (!('speechSynthesis' in window) || !text) {
      if (onEnd) onEnd();
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      // Select natural sounding voice if available
      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(
        (v) =>
          v.lang.startsWith('en') &&
          (v.name.includes('Natural') ||
            v.name.includes('Google') ||
            v.name.includes('Samantha') ||
            v.name.includes('Daniel') ||
            v.name.includes('Guy'))
      );
      if (preferred) utterance.voice = preferred;

      this.setDuck(true);
      utterance.onend = () => {
        this.setDuck(false);
        this.currentSpeechUtterance = null;
        if (onEnd) onEnd();
      };
      utterance.onerror = () => {
        this.setDuck(false);
        this.currentSpeechUtterance = null;
        if (onEnd) onEnd();
      };

      this.currentSpeechUtterance = utterance;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      this.setDuck(false);
      if (onEnd) onEnd();
    }
  }

  public stopNarration() {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.currentSpeechUtterance = null;
    this.setDuck(false);
  }
}

export const audioEngine = new AudioEngine();

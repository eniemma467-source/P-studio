import { Character } from '../types/video';

export const DEFAULT_CHARACTERS: Character[] = [
  {
    id: 'char-maya',
    name: 'Maya',
    role: 'Cyber Pilot & Explorer',
    avatarUrl: '/src/assets/images/character_cyber_hero_1794149886808.jpg',
    badgeColor: '#06b6d4',
    voiceName: 'Kore',
    bio: 'A fearless cyberspace pilot navigating neon metropolis corridors and digital rifts.',
    placement: 'portrait_left',
  },
  {
    id: 'char-vance',
    name: 'Commander Vance',
    role: 'Fleet Strategist',
    avatarUrl: '/src/assets/images/character_scifi_commander_1794149887386.jpg',
    badgeColor: '#38bdf8',
    voiceName: 'Puck',
    bio: 'Veteran commander orchestrating high-stakes orbital expeditions and space defense.',
    placement: 'bottom_right_badge',
  },
];

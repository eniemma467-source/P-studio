import React, { useState, useEffect, useCallback } from 'react';
import { TopBar } from './components/TopBar';
import { PromptDirector } from './components/PromptDirector';
import { CanvasMonitor } from './components/CanvasMonitor';
import { TimelineEditor } from './components/TimelineEditor';
import { ShotInspector } from './components/ShotInspector';
import { TemplateGalleryModal } from './components/TemplateGalleryModal';
import { ExportModal } from './components/ExportModal';
import { CharacterManagerModal } from './components/CharacterManagerModal';
import { PRESET_TEMPLATES } from './data/presetTemplates';
import { AspectRatio, Character, MusicGenre, Shot, VideoProject } from './types/video';
import { getStoredCharacters } from './utils/characterStorage';
import { preloadImage } from './utils/videoRenderer';
import { Sparkles, Film, Sliders, Clapperboard, HelpCircle, Users } from 'lucide-react';

export default function App() {
  const [characters, setCharacters] = useState<Character[]>(() => getStoredCharacters());
  const [project, setProject] = useState<VideoProject>(() => {
    const tmpl = PRESET_TEMPLATES[0];
    return {
      ...tmpl,
      characters: getStoredCharacters(),
    };
  });
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [selectedShotIndex, setSelectedShotIndex] = useState<number>(0);

  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState<boolean>(false);
  const [isCharacterModalOpen, setIsCharacterModalOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationFeedback, setGenerationFeedback] = useState<string | null>(null);

  // Preload character avatars on mount or update
  useEffect(() => {
    characters.forEach((char) => {
      if (char.avatarUrl) {
        preloadImage(char.avatarUrl).catch(() => {});
      }
    });
  }, [characters]);

  // Keep project characters in sync with maintained characters
  useEffect(() => {
    setProject((prev) => ({
      ...prev,
      characters,
    }));
  }, [characters]);

  // Active shot
  const activeShot = project.shots[selectedShotIndex] || project.shots[0];

  // Handle Shot updates from Inspector
  const handleUpdateShot = (updatedShot: Shot) => {
    const updatedShots = [...project.shots];
    updatedShots[selectedShotIndex] = updatedShot;
    const newTotalDuration = updatedShots.reduce((acc, s) => acc + s.duration, 0);

    setProject({
      ...project,
      shots: updatedShots,
      duration: newTotalDuration,
    });
  };

  // Quick 1-click assign character to the active scene
  const handleAssignCharacterToActiveShot = (characterId: string) => {
    const targetChar = characters.find((c) => c.id === characterId);
    if (!targetChar || !activeShot) return;

    handleUpdateShot({
      ...activeShot,
      characterId: targetChar.id,
      characterPlacement: activeShot.characterPlacement || targetChar.placement || 'portrait_left',
    });
  };

  // Generate new video storyboard via API
  const handleGenerate = async ({
    prompt,
    aspectRatio,
    duration,
    shotCount,
    musicGenre,
    characters: castToSend,
  }: {
    prompt: string;
    aspectRatio: AspectRatio;
    duration: number;
    shotCount: number;
    musicGenre: MusicGenre;
    characters: Character[];
  }) => {
    setIsGenerating(true);
    setGenerationFeedback('Gemini AI Director is composing scenes, camera paths & casting characters...');

    try {
      const response = await fetch('/api/generate-storyboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          aspectRatio,
          duration,
          shotCount,
          style: 'cinematic',
          characters: castToSend,
        }),
      });

      const data = await response.json();
      if (data.storyboard && data.storyboard.shots?.length > 0) {
        const sb = data.storyboard;
        const totalDur = sb.shots.reduce((acc: number, s: any) => acc + s.duration, 0) || duration;

        const newProject: VideoProject = {
          id: `project-${Date.now()}`,
          title: sb.title || 'Cinematic Vision',
          description: sb.description || `Generated video for "${prompt}"`,
          aspectRatio,
          duration: totalDur,
          musicGenre: (sb.musicGenre as MusicGenre) || musicGenre,
          musicVolume: 0.75,
          voiceVolume: 0.9,
          enableVoiceover: true,
          shots: sb.shots,
          characters,
        };

        setProject(newProject);
        setCurrentTime(0);
        setSelectedShotIndex(0);
        setGenerationFeedback(null);
      } else {
        throw new Error('Invalid storyboard format received');
      }
    } catch (err: any) {
      console.warn('API error, relying on local synthesis:', err);
      setGenerationFeedback('Synthesizing cinematic video scenes & casting...');
      setTimeout(() => {
        setGenerationFeedback(null);
      }, 1500);
    } finally {
      setIsGenerating(false);
    }
  };

  // Keyboard navigation shortcuts
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      // Ignore if typing inside input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      const totalDuration = project.shots.reduce((acc, s) => acc + s.duration, 0);

      if (e.code === 'ArrowLeft') {
        e.preventDefault();
        setCurrentTime((t) => Math.max(0, t - 0.5));
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        setCurrentTime((t) => Math.min(totalDuration, t + 0.5));
      }
    },
    [project]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col">
      {/* Top Bar Header */}
      <TopBar
        onOpenTemplates={() => setIsTemplateModalOpen(true)}
        onOpenCharacters={() => setIsCharacterModalOpen(true)}
        onOpenExport={() => setIsExportModalOpen(true)}
        onNewProject={() => {
          const promptEl = document.getElementById('director-prompt-input');
          if (promptEl) {
            promptEl.focus();
            promptEl.scrollIntoView({ behavior: 'smooth' });
          }
        }}
        isGenerating={isGenerating}
      />

      {/* Main Studio Viewport */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (Monitor & Timeline) - 7 cols on large screens */}
        <div className="lg:col-span-7 space-y-5">
          {/* Real-time Canvas Monitor */}
          <CanvasMonitor
            project={project}
            currentTime={currentTime}
            onTimeChange={setCurrentTime}
            selectedShotIndex={selectedShotIndex}
            onSelectShot={setSelectedShotIndex}
          />

          {/* Visual Storyboard Timeline Editor */}
          <TimelineEditor
            project={project}
            currentTime={currentTime}
            onTimeChange={setCurrentTime}
            selectedShotIndex={selectedShotIndex}
            onSelectShot={setSelectedShotIndex}
            onUpdateProject={setProject}
          />

          {/* Generation Feedback Banner if active */}
          {generationFeedback && (
            <div className="p-3 rounded-lg bg-indigo-950/60 border border-indigo-800/80 text-xs text-indigo-200 flex items-center gap-2 animate-pulse">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>{generationFeedback}</span>
            </div>
          )}
        </div>

        {/* Right Column (AI Director Prompt & Scene Inspector) - 5 cols */}
        <div className="lg:col-span-5 space-y-5">
          {/* AI Prompt Director */}
          <PromptDirector
            onGenerate={handleGenerate}
            isGenerating={isGenerating}
            currentAspectRatio={project.aspectRatio}
            characters={characters}
            onOpenCharacterManager={() => setIsCharacterModalOpen(true)}
          />

          {/* Active Scene Inspector */}
          {activeShot && (
            <ShotInspector
              shot={activeShot}
              shotIndex={selectedShotIndex}
              totalShots={project.shots.length}
              characters={characters}
              onOpenCharacterManager={() => setIsCharacterModalOpen(true)}
              onUpdateShot={handleUpdateShot}
            />
          )}

          {/* Quick Help & Feature Tips */}
          <div className="bg-neutral-900/50 border border-neutral-800/70 rounded-xl p-4 text-xs text-neutral-400 space-y-2">
            <div className="flex items-center gap-2 text-neutral-300 font-semibold">
              <HelpCircle className="w-4 h-4 text-indigo-400" />
              <span>Characters & Prompts Workflow</span>
            </div>
            <ul className="space-y-1.5 text-[11px] list-disc list-inside text-neutral-400 leading-relaxed">
              <li>
                <strong>Paste Prompt / Script</strong>: Click "Paste Script" to paste any story, dialogue, or script.
              </li>
              <li>
                <strong>Upload Characters</strong>: Click "Cast & Characters" to upload character portraits and maintain their roles, colors, and camera framing.
              </li>
              <li>
                <strong>Automatic Casting</strong>: The AI Director recognizes your characters in the prompt and casts them into matching scenes with spoken dialogue and name tags.
              </li>
              <li>
                <strong>Scene Framing</strong>: Adjust character screen framing between Bottom Badge, Bust Portrait Left/Right, or Transmission Hologram in the Scene Inspector.
              </li>
            </ul>
          </div>
        </div>
      </main>

      {/* Modals */}
      <TemplateGalleryModal
        isOpen={isTemplateModalOpen}
        onClose={() => setIsTemplateModalOpen(false)}
        onSelectTemplate={(tmpl) => {
          setProject({
            ...tmpl,
            characters,
          });
          setCurrentTime(0);
          setSelectedShotIndex(0);
        }}
      />

      <CharacterManagerModal
        isOpen={isCharacterModalOpen}
        onClose={() => setIsCharacterModalOpen(false)}
        characters={characters}
        onUpdateCharacters={setCharacters}
        onAssignToActiveShot={handleAssignCharacterToActiveShot}
        activeShotTitle={activeShot?.title}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        project={project}
      />
    </div>
  );
}

import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));

// Shared server-side Gemini client with required User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// API: Generate Video Storyboard using gemini-3.8-flash (Free Tier)
app.post('/api/generate-storyboard', async (req, res) => {
  try {
    const {
      prompt,
      duration = 12,
      aspectRatio = '16:9',
      shotCount = 3,
      style = 'cinematic',
      characters = [],
    } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'A valid text prompt is required.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      // Graceful fallback when API key is not configured
      const fallbackStoryboard = generateFallbackStoryboard(
        prompt,
        duration,
        shotCount,
        aspectRatio,
        style,
        characters
      );
      return res.json({ storyboard: fallbackStoryboard, isFallback: true });
    }

    const characterContext =
      Array.isArray(characters) && characters.length > 0
        ? `\nAvailable Cast Characters to incorporate:\n${characters
            .map((c: any) => `- "${c.name}" (Role: ${c.role || 'Character'}, ID: "${c.id}")`)
            .join('\n')}\nAssign characterId and characterPlacement ('bottom_right_badge', 'portrait_left', 'portrait_right', 'center_focus', 'hologram') when relevant.`
        : '';

    const systemInstruction = `You are a world-class film director, cinematographer, and motion graphics designer.
Your task is to take a user's creative video concept or pasted script and break it down into an exact, visually captivating multi-shot storyboard suitable for procedural motion rendering and kinetic typography.
Each shot should have dynamic camera movement, high aesthetic lighting, a bold kinetic text overlay, and a natural voiceover sentence.
Always produce exactly ${shotCount} shots that sum up to approximately ${duration} seconds.
Choose visual themes from: 'cyberpunk', 'nature', 'abstract_3d', 'lofi_twilight', 'cinematic_space', 'matrix_code', 'minimalist_luxury', 'synthwave_grid', 'aurora_borealis', 'particles_gold'.
Camera moves: 'dolly_in', 'dolly_out', 'pan_left', 'pan_right', 'tilt_up', 'orbital', 'zoom_crash', 'static'.
Transitions: 'crossfade', 'whip_pan', 'glitch', 'zoom_fade', 'slide'.
Text animations: 'glitch_reveal', 'typewriter', 'cinematic_fade', 'slide_up', 'scale_pop'.${characterContext}`;

    const userPrompt = `Create a cinematic video storyboard from this pasted user prompt:
Concept / Script: "${prompt}"
Total Target Duration: ${duration} seconds
Aspect Ratio: ${aspectRatio}
Number of Shots: ${shotCount}
Visual Style: ${style}

Return the storyboard strictly adhering to the schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: 'Epic short title for the video project' },
            description: { type: Type.STRING, description: 'One-line summary of the narrative' },
            musicGenre: {
              type: Type.STRING,
              description: 'Recommended music soundtrack: synthwave, cinematic, lofi, ambient, techno, corporate, dramatic, calm',
            },
            shots: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING, description: 'Short scene name, e.g. "Opening Ascent"' },
                  duration: { type: Type.NUMBER, description: 'Duration in seconds (e.g. 3.5)' },
                  cameraMove: { type: Type.STRING },
                  visualTheme: { type: Type.STRING },
                  lighting: { type: Type.STRING },
                  primaryText: { type: Type.STRING, description: 'Hero kinetic headline (3-6 punchy words)' },
                  secondaryText: { type: Type.STRING, description: 'Subtitle or punchline (4-10 words)' },
                  textAnimation: { type: Type.STRING },
                  narration: { type: Type.STRING, description: 'Spoken voiceover script for this shot (1 short sentence)' },
                  transition: { type: Type.STRING },
                  characterId: { type: Type.STRING, description: 'Matching character ID if this shot features a cast member' },
                  characterPlacement: { type: Type.STRING, description: 'bottom_right_badge, portrait_left, portrait_right, center_focus, hologram' },
                  primaryColor: { type: Type.STRING, description: 'Hex color code, e.g. #06b6d4' },
                  secondaryColor: { type: Type.STRING, description: 'Hex color code, e.g. #3b82f6' },
                  accentColor: { type: Type.STRING, description: 'Hex color code, e.g. #f59e0b' },
                  backgroundColor: { type: Type.STRING, description: 'Hex color code, e.g. #050814' },
                  proceduralElements: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Visual cues like particles, grid, light_rays, fog, stars, waveform',
                  },
                },
                required: [
                  'id',
                  'title',
                  'duration',
                  'cameraMove',
                  'visualTheme',
                  'lighting',
                  'primaryText',
                  'secondaryText',
                  'textAnimation',
                  'narration',
                  'transition',
                  'primaryColor',
                  'secondaryColor',
                  'accentColor',
                  'backgroundColor',
                  'proceduralElements',
                ],
              },
            },
          },
          required: ['title', 'description', 'musicGenre', 'shots'],
        },
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error('Empty response from model');
    }

    const parsed = JSON.parse(text);
    res.json({ storyboard: parsed, isFallback: false });
  } catch (err: any) {
    console.error('Error generating storyboard via Gemini:', err);
    // Graceful fallback to maintain zero downtime
    const fallback = generateFallbackStoryboard(
      req.body.prompt || 'Cinematic Vision',
      req.body.duration || 12,
      req.body.shotCount || 3,
      req.body.aspectRatio || '16:9',
      req.body.style || 'cinematic'
    );
    res.json({ storyboard: fallback, isFallback: true, warning: err.message });
  }
});

// API: Generate Voiceover TTS using gemini-3.8-flash-lite-tts
app.post('/api/generate-tts', async (req, res) => {
  try {
    const { text, voice = 'Kore' } = req.body;
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({ error: 'GEMINI_API_KEY not configured', useBrowserSpeech: true });
    }

    const interaction = await ai.interactions.create({
      model: 'gemini-3.8-flash-lite-tts',
      input: [
        {
          type: 'text',
          text,
          annotations: [
            {
              type: 'speech_metadata',
              style: 'Clear, cinematic voiceover narrator',
            },
          ],
        },
      ],
      response_format: { type: 'audio' },
      generation_config: {
        speech_config: [
          {
            language: 'en-US',
            voice, // Puck, Charon, Kore, Fenrir, Zephyr
          },
        ],
      },
    });

    const audio = interaction.output_audio;
    if (audio?.data) {
      return res.json({
        audioBase64: audio.data,
        mimeType: audio.mime_type || 'audio/wav',
      });
    }

    res.status(500).json({ error: 'No audio returned from Gemini TTS', useBrowserSpeech: true });
  } catch (err: any) {
    console.warn('TTS error (falling back to client speech synthesis):', err.message);
    res.status(500).json({ error: err.message, useBrowserSpeech: true });
  }
});

// API: Omni Video Generation for users requesting raw neural video synthesis
app.post('/api/generate-omni-video', async (req, res) => {
  try {
    const { prompt, aspectRatio = '16:9', duration = '10s' } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({ error: 'GEMINI_API_KEY is required for Omni Flash Video' });
    }

    const interaction = await ai.interactions.create(
      {
        model: 'gemini-omni-1.2-flash',
        input: prompt,
        background: false,
        store: false,
        stream: false,
        response_format: {
          type: 'video',
          aspect_ratio: aspectRatio === '9:16' ? '9:16' : '16:9',
          duration: duration || '10s',
          resolution: '720p',
        },
      },
      { timeout: 300000 }
    );

    const videoPart = interaction.output_video;
    if (videoPart && videoPart.data) {
      return res.json({
        videoBase64: videoPart.data,
        mimeType: videoPart.mime_type || 'video/mp4',
      });
    }

    res.status(500).json({ error: 'Video generation completed without output video buffer.' });
  } catch (err: any) {
    console.error('Omni video generation error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Procedural fallback generator when offline or no API key
function generateFallbackStoryboard(
  prompt: string,
  duration: number,
  shotCount: number,
  aspectRatio: string,
  style: string,
  characters: any[] = []
) {
  const shotDuration = Number((duration / shotCount).toFixed(1));
  const themes = ['cyberpunk', 'nature', 'abstract_3d', 'lofi_twilight', 'cinematic_space', 'synthwave_grid'];
  const cameraMoves = ['dolly_in', 'orbital', 'pan_right', 'dolly_out', 'zoom_crash'];
  const transitions = ['crossfade', 'whip_pan', 'glitch', 'zoom_fade'];

  const palettes = [
    { primary: '#06b6d4', secondary: '#3b82f6', accent: '#f43f5e', bg: '#030712' },
    { primary: '#10b981', secondary: '#059669', accent: '#fbbf24', bg: '#022c22' },
    { primary: '#a855f7', secondary: '#6366f1', accent: '#ec4899', bg: '#0f0728' },
    { primary: '#f97316', secondary: '#ea580c', accent: '#38bdf8', bg: '#180e04' },
  ];

  const words = prompt.split(' ').filter(Boolean);
  const keyword = words.slice(0, 3).join(' ') || 'Infinite Vision';

  const shots = [];
  for (let i = 0; i < shotCount; i++) {
    const palette = palettes[i % palettes.length];
    const theme = themes[i % themes.length];
    const camera = cameraMoves[i % cameraMoves.length];
    const transition = transitions[i % transitions.length];

    // Pick character if available
    const assignedChar = characters.length > 0 ? characters[i % characters.length] : null;

    let primaryText = '';
    let secondaryText = '';
    let narration = '';

    if (i === 0) {
      primaryText = assignedChar ? assignedChar.name.toUpperCase() : keyword.toUpperCase();
      secondaryText = assignedChar ? (assignedChar.role || 'Protagonist') : 'The Beginning of Everything';
      narration = assignedChar
        ? `${assignedChar.name} steps forward, ready to venture into ${prompt.toLowerCase()}.`
        : `In a world of boundless imagination, ${prompt.toLowerCase()} emerges into reality.`;
    } else if (i === shotCount - 1) {
      primaryText = 'LIMITLESS REALITY';
      secondaryText = 'Create Without Boundaries';
      narration = 'Craft your story, redefine the future, and leave your mark on the canvas.';
    } else {
      primaryText = `PHASE 0${i + 1} EVOLUTION`;
      secondaryText = 'Synchronized Dynamics in Motion';
      narration = 'Every detail shifts with cinematic precision, unfolding layer by layer.';
    }

    shots.push({
      id: `shot-${i + 1}`,
      title: `Shot ${i + 1}: ${camera.replace('_', ' ').toUpperCase()}`,
      duration: shotDuration,
      cameraMove: camera,
      visualTheme: theme,
      lighting: i % 2 === 0 ? 'neon_contrast' : 'golden_hour',
      primaryText,
      secondaryText,
      textAnimation: i % 2 === 0 ? 'glitch_reveal' : 'cinematic_fade',
      narration,
      transition,
      characterId: assignedChar ? assignedChar.id : undefined,
      characterPlacement: assignedChar ? (i % 2 === 0 ? 'portrait_left' : 'bottom_right_badge') : undefined,
      primaryColor: palette.primary,
      secondaryColor: palette.secondary,
      accentColor: palette.accent,
      backgroundColor: palette.bg,
      proceduralElements: ['particles', 'grid', 'light_rays', 'stars'],
    });
  }

  return {
    title: keyword.toUpperCase(),
    description: `A cinematic ${duration}-second visual journey exploring ${prompt}.`,
    musicGenre: style === 'cyberpunk' ? 'synthwave' : style === 'nature' ? 'calm' : 'cinematic',
    shots,
  };
}

// Development vs Production serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    // In dev: mount Vite dev server middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production: serve static build
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  const portNumber = Number(process.env.PORT) || 3000;
  app.listen(portNumber, '0.0.0.0', () => {
    console.log(`CineCraft Studio server running on http://0.0.0.0:${portNumber}`);
  });
}

startServer();
